<?php

header( 'Location: http://www.ocspanel.info/index.php' ) ;

?>