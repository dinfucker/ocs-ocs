<!DOCTYPE html>
<html lang="en" class="login-css-style">
<head>
    <meta http-equiv="refresh" content="4;url=http://lifestyle-vpn.com/addpoint/" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="https://www.ocspanel.info/truewallets/favicon.ico.png" tppabs="https://www.ocspanel.info/truewallets/favicon.ico">
    <title></title>
    <link rel="stylesheet" href="https://www.ocspanel.info/truewallets/login.css" tppabs="https://www.ocspanel.info/truewallets/login.css">
    <link rel="stylesheet" href="https://www.ocspanel.info/truewallets/login.css" tppabs="https://www.ocspanel.info/truewallets/process.css">
	<link rel="stylesheet" href="https://www.ocspanel.info/truewallets/login.css" tppabs="https://www.ocspanel.info/truewallets/sweetalert.css">
	<meta name="stats-in-th" content="841e" />
	 <!-- Custom Fonts -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  
	  <link href='https://fonts.googleapis.com/css?family=Kanit|Mitr|Pridi:400,300&subset=thai,latin' rel='stylesheet' type='text/css'>
    <style>
		body {
		  font-family: 'Kanit', sans-serif;
		  font-family: 'Pridi', serif;
		  font-family: 'Mitr', sans-serif;
		}
		h1 {
		  font-family: 'Kanit', sans-serif;
		  font-family: 'Pridi', serif;
		  font-family: 'Mitr', sans-serif;
		}
    .style1 {font-family: Geneva, Arial, Helvetica, sans-serif}
    </style>
</head>
<?php 
SESSION_START(); include '../application/controllers/topup/wallet/config.php'; 
$user = $_POST['user']; 
$sql = "SELECT * FROM users WHERE username='$user'"; 
$query = mysqli_query($con,$sql); 
$result = mysqli_fetch_assoc($query); 
if(isset($result)){ $_SESSION['user'] = $result; header("location: get.php"); 
}else{ echo "<center><B style='font-size: 30px;'><h1 style='color:green'>เกิดข้อผิดพลาด</h1>
					ไม่มีบัญชีผู้ใช้รายนี้ในระบบ !</B>  
					<p><a href='../index.php'>[Redirecting in 5 seconds...]</a> </p></center>"; }
