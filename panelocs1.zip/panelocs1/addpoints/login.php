<?php 
session_start();
        if(isset($_REQUEST['Username'])){
				//connection
                  include("connection.php");
				//?????? user & password
                  $Username = $_REQUEST['Username'];
                  $Password = md5($_REQUEST['Password']);
				//query 
                  $sql="SELECT * FROM User Where Username='".$Username."' and Password='".$Password."' ";

                  $result = mysqli_query($con,$sql);
				
                  if(mysqli_num_rows($result)==1){

                      $row = mysqli_fetch_array($result);

                      $_SESSION["UserID"] = $row["ID"];
                      $_SESSION["User"] = $row["Firstname"]." ".$row["Lastname"];
                      $_SESSION["Userlevel"] = $row["Userlevel"];

                      if($_SESSION["Userlevel"]=="A"){ //??????? admin ??????????????? admin_page.php

                        Header("Location: admin_page.php");

                      }

                      if ($_SESSION["Userlevel"]=="M"){  //??????? member ??????????????? user_page.php

                        Header("Location: user_page.php");

                      }

                  }else{
                    echo "<script>";
                        echo "alert(\" user ????  password ??????????\");"; 
                        echo "window.history.back()";
                    echo "</script>";

                  }

        }else{


             Header("Location: form.php"); //user & password incorrect back to login again

        }
?>