<?php 
            
            $var_46692a87502c95356a00c9e45986c5cd=$_SERVER['SERVER_NAME'];
            $var_60ea1edc0b2b28fedb50d5cad3746e09="41";
            $var_94e19110068344befb9488f3071245ef = "http://php.xn--l3clxf6cwbe0gd7j.com/api/";

            $var_9acd13aaab2217365532d287b39dfd9e="domain=$var_46692a87502c95356a00c9e45986c5cd&product=".urlencode($var_60ea1edc0b2b28fedb50d5cad3746e09);

            $var_e8061cb59b46a4a2bda304354b950448 = curl_init();
            curl_setopt($var_e8061cb59b46a4a2bda304354b950448,CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($var_e8061cb59b46a4a2bda304354b950448, CURLOPT_URL, $var_94e19110068344befb9488f3071245ef);
            curl_setopt($var_e8061cb59b46a4a2bda304354b950448, CURLOPT_POST, true);
            curl_setopt($var_e8061cb59b46a4a2bda304354b950448, CURLOPT_POSTFIELDS, $var_9acd13aaab2217365532d287b39dfd9e);
            $var_f7f0a97a1c1711a6c707740e6835973a= json_decode(curl_exec($var_e8061cb59b46a4a2bda304354b950448), true);
            curl_close($var_e8061cb59b46a4a2bda304354b950448);

            if($var_f7f0a97a1c1711a6c707740e6835973a['status'] != 200) {
            $var_0097b357800d476540b254cb19296657 = "<div align='center'>
    <table width='100%' border='0' style='padding:15px; border-color:#F00; border-style:solid; background-color:#FF6C70; font-family:Tahoma, Geneva, sans-serif; font-size:22px; color:white;'>

    <tr>

        <td><b>You don't have permission to use this product. The message from server is: <%returnmessage%> <br > Contact the product developer.</b></td >

    </tr>

    </table>

</div>";
            $var_7e48c1e32e8e678af5c64d4a7599ff37 = '<%returnmessage%>';
            $var_c930c60f464107ba17fca3de801d7d9b = $var_f7f0a97a1c1711a6c707740e6835973a['message'];
            $var_0097b357800d476540b254cb19296657 = str_replace($var_7e48c1e32e8e678af5c64d4a7599ff37, $var_c930c60f464107ba17fca3de801d7d9b, $var_0097b357800d476540b254cb19296657);


            die( $var_0097b357800d476540b254cb19296657 );

            }
            ?>