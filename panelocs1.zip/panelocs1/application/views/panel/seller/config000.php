<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      ไฟล์ CONFIG VPN-SSH-APK
      </h1>
	 
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i>หน้าหลัก</a></li>
        <li class="active">CONFIG VPN</li>
    </ol>
    </section>
    <br>
    <!-- Main content -->
    <div class="row">
  <section class="content">   
       <div class="col-sm-12 ">    
        <div class="box box-widget widget-user">
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('/asset/img/Background/Background1.png') ?>') center center;">
              <h3 class="widget-user-username"><B><B></h3>
			  <center><span class="description-text"><span style="font-size: 16px;"  class="badge bg-purple">CONFIG OPENVPN</span></center>
              <h4 class="widget-user-desc"><B><B></h4>
              <p>     </p>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="<?php echo  base_url('asset/img/icon/i3.png') ?>" alt="User Avatar">
            </div>
                  
       <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-purple">โหลดไฟล์ VPN TRUE-DTAC</span></span>
         </div>
         
		 
		 
		 <ul class="nav nav-stacked">
<div class="box-body">
<center>
</center><table class="table">
<tbody><tr>
<td><span class="label label-success">ชื่อเซิร์ฟเวอร์ </span></td>
<td><span class="label label-success">TRUE-DTAC </span></td>
<td><span class="label label-success">TRUE MAX Speed</span></td> 
</tr>
		

		<tr> 
<td><b> SG-1-LIFESTYLE </b></td>
<td><b><a href="/web/vpn/DTAC/T&D-SG-1-LIFESTYLE.ovpn" class="btn btn bg-navy">T&D </a><b></b></b></td>
<td><b><a href="/web/vpn/DTAC/TRUEMAX-SG-1-LIFESTYLE.ovpn" class="btn bg-maroon">TRUE</a><b></b></b></td>
</tr>
<tr> 
<td><b> SG-2-LIFESTYLE </b></td>
<td><b><a href="/web/vpn/DTAC/T&D-SG-2-LIFESTYLE.ovpn" class="btn btn bg-navy">T&D</a><b></b></b></td>
<td><b><a href="/web/vpn/DTAC/TRUEMAX-SG-2-LIFESTYLE.ovpn" class="btn bg-maroon">TRUE</a><b></b></b></td>
</tr>
<td><b> TH-VIP1-LIFESTYLE </b></td>
<td><b><a href="/web/vpn/DTAC/T&D-TH-VIP1-LIFESTYLE.ovpn" class="btn btn bg-navy">T&D</a><b></b></b></td>
<td><b><a href="/web/vpn/DTAC/TRUEMAX-TH-VIP1-LIFESTYLE.ovpn" class="btn bg-maroon">TRUE</a><b></b></b></td>
</tr>
<td><b> TH-VIP2-LIFESTYLE </b></td>
<td><b><a href="/web/vpn/DTAC/T&D-TH-VIP2-LIFESTYLE.ovpn" class="btn btn bg-navy">T&D</a><b></b></b></td>
<td><b><a href="/web/vpn/DTAC/TRUEMAX-TH-VIP2-LIFESTYLE.ovpn" class="btn bg-maroon">TRUE</a><b></b></b></td>
</tr>
<td><b> TH-PC1-LIFESTYLE </b></td> 
<td><b><a href="/web/vpn/TRUE/TRUE-TH-PC1-LIFESTYLE.ovpn" class="btn bg-maroon">TRUE</a><b></b></b></td>
<td><b><a href="/web/vpn/DTAC/TRUEMAX-TH-PC1-LIFESTYLE.ovpn" class="btn bg-maroon">TRUE</a><b></b></b></td>
</tr>
<td><b> TH-PC2-LIFESTYLE </b></td> 
<td><b><a href="/web/vpn/TRUE/TRUE-TH-PC2-LIFESTYLE.ovpn" class="btn bg-maroon">TRUE</a><b></b></b></td>
<td><b><a href="/web/vpn/DTAC/TRUEMAX-TH-PC2-LIFESTYLE.ovpn" class="btn bg-maroon">TRUE</a><b></b></b></td>
</tr>
</tr>
<!--td><b> ไทยฟรี 1 วัน </b></td> 
<td><b><a href="/web/vpn/True-Dtac.ovpn" class="btn btn-danger">TRUE</a><b></b></b></td>
<td><b><a href="/web/vpn/True-Dtac.ovpn" class="btn btn-info">DTAC</a><b></b></b></td>
</tr-->

		 
</tbody>
</table>
</div>
</ul>
</div>

   
       
     
		 

		 
		 
<!--div class="row">
  <section class="content">   
       <div class="col-sm-12 ">    
        <div class="box box-widget widget-user">
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/200.png') ?>') center center;">
              <h3 class="widget-user-username"><B><B></h3>
			  <center><span class="description-text"><span style="font-size: 16px;"  class="badge bg-navy">CONFIG Apk Custom</span></center>
              <h4 class="widget-user-desc"><B><B></h4>
              <p>     </p>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="https://cdn6.aptoide.com/imgs/b/7/d/b7d7b0bdcca5617d95aa33896c95c3ff_icon.png?w=240" alt="User Avatar">
            </div>
                  
       <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-navy">โหลดไฟล์ Apk Custom</span></span><br><br>
			<span class="description-text"><span style="font-size: 16px;"  class="badge bg-navy">ดีแทคโปรไลน์ (เล่นเกมได้ ทีวีไลน์ได้ ok)</span></span><br><br>
			<span class="description-text"><span style="font-size: 16px;"  class="badge bg-navy"><a href="/web/apk/apk-custom.apk"><i class="fa fa-android"> </i> โหลดแอพ Apk Custom กดตรงนี้ </span></span><a/> 
         </div> 
         
		 
		 
		 <ul class="nav nav-stacked">
<div class="box-body">
<center>
</center><table class="table">
<tbody><tr>
<td><span class="label label-success">ชื่อเซิร์ฟเวอร์ </span></td>
<!--td><span class="label label-danger">ไฟล์ซิมทรูมูฟ TRUE</span></td>
<td><span class="label label-info">ไฟล์ซิมดีแทค DTAC</span></td>
</tr>
		

		<tr> 
<td><b> TH-VIP1-LIFESTYLE </b></td>
<td><b><a href="/web/apk/DTAC-TH-VIP1-LIFESTYLE.acm" class="btn btn-info">DTAC</a><b></b></b></td>
</tr>
<td><b> TH-VIP2-LIFESTYLE </b></td>
<td><b><a href="/web/apk/DTAC-TH-VIP2-LIFESTYLE.acm" class="btn btn-info">DTAC</a><b></b></b></td>
</tr>

</tr>

	
		  
</tbody>
</table>
</div>
</ul>
</div-->
       

						      </center> 
                   	    </table>
        			  </div>
        			</ul>
				  </div>
 	        </div>
 		
 
       </section>      
  </div></div>  </div></div>  </div></div> 