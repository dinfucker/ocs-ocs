<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper clearfix">
<!-- Main content -->
  <div class="col-md-12 form f-label" >
  <?php if($this->session->flashdata("messagePr")){?>
    <div class="alert alert-info">      
      <?php echo $this->session->flashdata("messagePr")?>
    </div>
  <?php } ?>
        <!-- Profile Image -->
    <div class="box box-success pad-profile">
     	<div class="box-header with-border">
        <h3 class="box-title">Description <small></small></h3>
    </div>
		<div class="box-body box-profile">
  		<div class="row">
		<?php if (isset($success)) {echo $success; }?>		
        	<div class="col-xs-12">
            <div class="box-header with-border">
       <!-- Profile Image -->    		
			
					<div class="form-group has-feedback">
  
     <div class="row">
         <div class="col-lg-12">
             <div class="box box-widget widget-user">               
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('/asset/img/Background/Background4.jpg') ?>') center center;">
              <h3 class="widget-user-username"><?php echo  $server->ServerName ?></h3>
              <h5 class="widget-user-desc"><?php echo  $server->Expired ?> วัน <?php echo  $server->Price?> บาท <B></h5>
              
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="<?php echo  base_url('asset/img/icon/i3.png') ?>" alt="User Avatar">
            </div>
			 <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">รายละเอียดเซิร์ฟเวอร์</span></span>
         </div>
         
              <ul class="nav nav-stacked">
                <li><a href="#"><B> เซิร์ฟเวอร์ </B><span class="pull-right"><B>IP HOST</B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-aqua"><?php echo  $server->Location?></span> <span style="font-size: 16px;" class="pull-right badge bg-purple">แสดงเมื่อเช่าแล้ว</span></a></li>
                
                <li><a href="#"><B> PORT</B> <span class="pull-right"><B>จำกัดการเชื่อมต่อ</B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-maroon"><?php echo  $server->OpenSSH?>, <?php echo  $server->Dropbear?></span><span style="font-size: 16px;" class="pull-right badge bg-navy"> VPN <?php echo  $server->limitvpn?> เครื่อง <!--?php echo  $row['limitssh']?--></span></a></li>
                
                <li><a href="#"> <B>วันใช้งาน </B><span class="pull-right"> <B>จำกัด</B> </span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-purple"><?php echo  $server->Expired?> วัน </span><span style="font-size: 16px;" class="pull-right badge bg-blue"><?php echo  $server->MaxUser?> คน/วัน </span></a></li>
                
                <li><a href="#"> <B>ราคา</B> <span class="pull-right"><B> สถานะเซิร์ฟเวอร์</B> </span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-green"><?php echo  $server->Price?> บาท </span><span style="font-size: 16px;" class="pull-right badge bg-orange"> <?php if ($server->Status) { echo 'ออนไลน์';} else {echo "เซิร์ฟเวอร์เต็ม";}?></span></a></li>
                
              </ul>
            </div>
			
                
            <div class="col-lg-12">
                <?php if (isset($message)) {echo $message; }?>
            </div>
                    
                    <div class="box-body">
					<?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  $error ?></div>
					</div>
					<?php endif;?>
                    <?php echo  form_open() ?>
						<div class="form-group">
							<label for="username">Username</label>
							<input type="text" name="username" class="form-control" id="username" placeholder="ตัวอักษรอย่างน้อย 5 ตัวห้ามใช้ภาษาไทยหรืออักษรพิเศษ"/>
						</div>
						<div class="form-group">
							<label for="password">Password </label>
							<input type="text" name="password" id="password" class="form-control" placeholder="ตัวอักษรหรือตัวเลขอย่างน้อย 5 ตัว"/>
						</div> 
                    
                    </div>
                    <div class="box-footer text-center"> 
						<button class="btn bg-green"><i class="fa fa-money"></i> ชำระเงิน </button>                   
                        <a href="/servers" class="btn bg-yellow"><i class="fa fa-rotate-left"></i> ย้อนกลับ</a>
																		</div>
                    </form>
                    </div>
                </div>
            </div>
			
        

      </section>
</div>