<div class="content-wrapper clearfix">
<!-- Main content -->
  <div class="col-md-12 form f-label" >
          <!-- Profile Image -->
    <div class="box box-success pad-profile">
     	<div class="box-header with-border">
        <h3 class="box-title">Load Filesvpn <small></small></h3>
    </div>
		<div class="box-body box-profile">
  		<div class="row">
				
        	<div class="col-xs-12">
            <div class="box-header with-border">
       <!-- Profile Image -->    		
					<div class="form-group has-feedback">
    <section class="content">
	    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i>หน้าหลัก</a></li>
        <li class="active">CONFIG VPN ทรูดีแทคติดง่าย </li>
    </ol>
            <div class="row">

                	<div class="col-sm-6 col-md-6 col-lg-12">
                    <div class="box box-solid">                     
                        <div class="box-body no-padding">
                           <ul class="nav nav-pills nav-stacked">
                              <li><a href="/web/vpn/DTAC/T&D-TH-VIP1-LIFESTYLE.ovpn"><span class="widget-user-username"><b><i class="fa fa-connectdevelop"></i> ทรูดีแทค VIP1</b><span class="badge bg-aqua pull-right"> ดาวน์โหลด </span></span></a>
							   <li><a href="/web/vpn/DTAC/T&D-TH-VIP2-LIFESTYLE.ovpn"><span class="widget-user-username"><b><i class="fa fa-connectdevelop"></i> ทรูดีแทค VIP2</b><span class="badge bg-aqua pull-right"> ดาวน์โหลด </span></span></a>
							    <li><a href="/web/vpn/DTAC/T&D-SG-1-LIFESTYLE.ovpn"><span class="widget-user-username"><b><i class="fa fa-connectdevelop"></i> ทรูดีแทค SG1</b><span class="badge bg-aqua pull-right"> ดาวน์โหลด </span></span></a>
								 <li><a href="/web/vpn/DTAC/T&D-SG-2-LIFESTYLE.ovpn"><span class="widget-user-username"><b><i class="fa fa-connectdevelop"></i> ทรูดีแทค SG2</b><span class="badge bg-aqua pull-right"> ดาวน์โหลด </span></span></a>
								  <li><a href="/web/vpn/TRUE/TRUE-TH-PC1-LIFESTYLE.ovpn"><span class="widget-user-username"><b><i class="fa fa-connectdevelop"></i> ทรู PC1</b><span class="badge bg-aqua pull-right"> ดาวน์โหลด </span></span></a>
								   <li><a href="/web/vpn/TRUE/TRUE-TH-PC2-LIFESTYLE.ovpn"><span class="widget-user-username"><b><i class="fa fa-connectdevelop"></i> ทรู PC2</b><span class="badge bg-aqua pull-right"> ดาวน์โหลด </span></span></a>
                                
                       </li>
                     </ul>                              

                 </div>
               </div>
             </div>

                


            </div>
            <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i>หน้าหลัก</a></li>
        <li class="active">CONFIG VPN ทรูทะลุโปร</li>
    </ol>
<div class="row">

                	<div class="col-sm-6 col-md-6 col-lg-12">
                    <div class="box box-solid">                     
                        <div class="box-body no-padding">
                           <ul class="nav nav-pills nav-stacked">
						   
                               <li><a href="/web/vpn/DTAC/TRUEMAX-TH-VIP1-LIFESTYLE.ovpn"><span class="widget-user-username"><b><i class="fa fa-connectdevelop"></i> ทรูทะลุโปร VIP1</b><span class="badge bg-aqua pull-right"> ดาวน์โหลด </span></span></a>
							   <li><a href="/web/vpn/DTAC/TRUEMAX-TH-VIP2-LIFESTYLE.ovpn"><span class="widget-user-username"><b><i class="fa fa-connectdevelop"></i> ทรูทะลุโปร VIP2</b><span class="badge bg-aqua pull-right"> ดาวน์โหลด </span></span></a>
							    <li><a href="/web/vpn/DTAC/TRUEMAX-SG-1-LIFESTYLE.ovpn"><span class="widget-user-username"><b><i class="fa fa-connectdevelop"></i> ทรูทะลุโปร SG1</b><span class="badge bg-aqua pull-right"> ดาวน์โหลด </span></span></a>
								 <li><a href="/web/vpn/DTAC/TRUEMAX-SG-2-LIFESTYLE.ovpn"><span class="widget-user-username"><b><i class="fa fa-connectdevelop"></i> ทรูทะลุโปร SG2</b><span class="badge bg-aqua pull-right"> ดาวน์โหลด </span></span></a>
								  <li><a href="/web/vpn/DTAC/TRUEMAX-TH-PC1-LIFESTYLE.ovpn"><span class="widget-user-username"><b><i class="fa fa-connectdevelop"></i> ทรูทะลุโปร PC1</b><span class="badge bg-aqua pull-right"> ดาวน์โหลด </span></span></a>
								   <li><a href="/web/vpn/DTAC/TRUEMAX-TH-PC2-LIFESTYLE.ovpn"><span class="widget-user-username"><b><i class="fa fa-connectdevelop"></i> ทรูทะลุโปร PC2</b><span class="badge bg-aqua pull-right"> ดาวน์โหลด </span></span></a>
                                
                       </li>
                     </ul>                              

                 </div>
               </div>
             </div>
              



            </div>
    </section></div>  </div></div>  </div></div> 
