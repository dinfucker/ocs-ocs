  <div class="content-wrapper" style="min-height: 643px;">
    <section class="content-header">
      <h1>
        TRUE WALLET
      </h1>
    <ol class="breadcrumb">
        <li><a href="/index"><i class="fa fa-fort-home"></i> หน้าหลัก </a></li>
        <li class="active">TRUE WALLET</li>
    </ol>
    </section>

    <section class="content">
       <div class="row">
	           
		  <div class="col-md-12">
          <div class="box box-widget widget-user">
         	<div class="widget-user-header bg-black" style="background: url('/asset/img/Background/Background2.png') center center;">
              <h5 class="widget-user-username"> <b> ชื่อบัญชี </b><span class="pull-right"><b> ยอดเงินคงเหลือ </b></span></h5><b>
              <h4 class="widget-user-desc"><span style="font-size: 14px;" class="badge bg-purple"><b>  <?php echo  $user->username ?> </b></span><span style="font-size: 14px;" class="pull-right badge bg-blue"><b>  <?= $user -> saldo ?> บาท </b></span></h4>
            </b></div><b>
            <div class="widget-user-image">
              <img class="img-circle" src="http://www.ocspanel.info/asset/img/t-wall.png" alt="User Avatar">
            </div>
 
				 <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;" class="badge bg-red">เบอร์สำหรับเติมเงิน</span></span>
         </div>
         
              <ul class="nav nav-stacked">
                <li><a href="#"><b> ชื่อ WALLET </b><span class="pull-right"><b> เบอร์ WALLET </b></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-aqua">   			  จตุรพร สุริยา			     </span> <span style="font-size: 16px;" class="pull-right badge bg-maroon"> 			  			  			  			  096-639-4896			  			  			  			   </span></a></li>                                        
              </ul>
            </div>

	<div class="box-footer">
		<form action="/truewallets/input.php" method="post">
           <center><span class="description-text"><span style="font-size: 12px;" class="badge bg-light"><b> USERNAME <?php echo  $user->username ?> </b></span></span></center>
  <input name="user" type="hidden" value="<?php echo  $user->username ?>" id="user">
<b></b><h5><b> 1. โอนเงินไปยังเบอร์ : 096-639-4896  </b></h5>
<b></b><h5><b> 2. โอนเงินเสร็จแล้วให้รีบ นำเลขอ้างอิงมาใส่   </b></h5>
<div class="form-group text-center">
						<a href="http://tmwallet.thaighost.net/images/transactionid.jpg" target="_transactionid">ดูตัวอย่างเลขที่อ้างอิง</a>	  
    					
        <br>
    		<div class="form-group">
							<button type="submit" name="submit" class="btn btn-success pull-left waves-effect waves-light"><i class="fa fa-lock"></i> กดถัดไปเพื่อยืนยัน </button>
           <a href="/index" class="btn btn-warning pull-right waves-effect waves-light"><i class="fa fa-home"></i> ย้อนกลับ</a>
	
 						</div>
 						</form>
					 </div>        
 				</b></div><b> 
			</b></div><b>
                   
            
            </b></div><b>
          </b></section></div>