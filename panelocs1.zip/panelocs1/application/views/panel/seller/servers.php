<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Content Wrapper. Contains page content -->



<div class="content-wrapper clearfix">
          <div class="col-sm-12"> 
<div class="info-box bg-info"style="background: url('<?php echo  base_url('/asset/img/Background/Background2.png') ?>') center center;">
<span class="info-box-icon"><i class="fa fa-ge"></i></span>
<div class="info-box-content">
<span class="info-box-number">ยอดเงินคงเหลือ » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-blue"><?= $user -> saldo ?> บาท</span>
<span class="info-box-number">ชื่อบัญชี » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-blue"><?php echo  $user->username ?></span></span>
<div class="progress">
<div class="progress-bar" style="width: 0%"></div>
</div>
<span class="progress-description">
<a href="<?= base_url('main/'.$_SESSION['username'].'/topups') ?>">เติมเงิน <i class="fa fa-arrow-circle-right"></i></a>
</span>
</div>
</div>
</div>
<section class="content">
<section class="content-header">

	  <?php if (isset($message)) {echo $message; }?>
  </section>                  
       
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#activity" data-toggle="tab" aria-expanded="true">ดูทั้งหมด</a></li>
              <li class=""><a href="#timeline" data-toggle="tab" aria-expanded="false">วิธีเติมเงิน</a></li>
              <li class=""><a href="#settings" data-toggle="tab" aria-expanded="false">เงื่อนไข</a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="activity">
                <!-- The timeline -->
                <ul class="timeline timeline-inverse">
                  <!-- timeline time label -->
                  <li class="time-label">
                        <span class="bg-aqua">
                          เซิฟเวอร์ทั้งหมด!!
                        </span>
                  </li>
                  <!-- /.timeline-label -->
				  
				  
				  

<!-- timeline item -->
<?php foreach($server as $row): ?>
                  <li>
                    <i class="fa fa-bookmark bg-blue"></i>
					
                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> <?php if ($row['Status']) { echo 'เช่าได้';} else {echo "เต็มแล้ว";}?></span>

                      <h3 class="timeline-header"><a href="#"><?php if ($row['Status']) { echo $row['ServerName'];} else {echo "เซิร์ฟเวอร์เต็ม";}?></a></h3>
					  

                      <div class="timeline-body">
              <ul class="nav nav-stacked">

              </ul>
		
                      <div class="timeline-footer">
					  <a href='<?php echo base_url('truemoney') ?>'><span class="label label-warning"><?php echo  $row['Location']?></span></a>  
					  <a href='<?php echo base_url('truewallet') ?>'><span class="label label-danger"><?php echo  $row['Price']?> บาท</span></a>
					  <a href='<?php echo base_url('truewallet') ?>'><span class="label label-info"><?php echo  $row['Expired']?> วัน</span></a>
					  <a href='<?php echo  base_url('index/seller/'.$_SESSION['username'].'/buy/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id']) ?>'><span class="label label-success">เช่าเลย</span></a>
                      </div>
                    </div>
                  </li>
<!-- END timeline item -->
<?php endforeach; ?>



                  <!-- /.timeline-label -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-calculator bg-purple"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 2 days ago</span>

                      <h3 class="timeline-header"><a href="#">โบนัสการเติมเงิน</a></h3>

                      <div class="timeline-body">
ยังไม่มีช่วงนี้จน...


					  </div>
                      <div class="timeline-footer">
					  <a href='<?php echo base_url('truemoney') ?>'><span class="label label-warning">Truemoney</span></a>  <a href='<?php echo base_url('truewallet') ?>'><span class="label label-danger">Truewallet</span></a>
                      </div>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <li>
                    <i class="fa fa-clock-o bg-gray"></i>
                  </li>
                </ul>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="timeline">
                <!-- The timeline -->
                <ul class="timeline timeline-inverse">
                  <!-- timeline time label -->
                  <li class="time-label">
                        <span class="bg-red">
                          ขั้นตอนการเติมเงิน True Wallet
                        </span>
                  </li>
                  <!-- /.timeline-label -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-envelope bg-blue"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 12:05</span>

                      <h3 class="timeline-header"><a href="#">Support Team</a><br /> ระบบเติมเงินอัตโนมัติ</h3>

                      <div class="timeline-body">
เพียงแค่ท่านนำเลขอ้างอิง<br />
จากการเติมโอนเงินมาใส่<br />
โอนเงิน มาตามเบอร์ด้านล่าง<br />
096-639-4896 ( จตุรพร  สุริยา... )<br />
แล้วจึงกด <span class="style3">ยืนยันการโอนเงิน</span>                      </div>
                      <div class="timeline-footer">
                        <a class="btn btn-primary btn-xs">ไปเติมเงิน</a>
                        <a class="btn btn-danger btn-xs">ไว้ทีหลัง</a>
                      </div>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-user bg-aqua"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 5 mins ago</span>

                      <h3 class="timeline-header no-border"><a href="#">เปิดแอปทรูวอลเลต</a> ขั้นตอนที่ 1</h3>
                      <div class="timeline-body">
                        Take me to your leader! <br />
						<!--img src="<?php echo base_url('asset/i/howto-wallet1.jpg')?>" width="100%" height="100%" /-->                      </div>
                      <div class="timeline-footer">
         
					</div>						  
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-comments bg-yellow"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 9 mins ago</span>

                      <h3 class="timeline-header no-border"><a href="#">กลับมายืนยันที่เว็บ</a> ขั้นตอนที่ 2</h3>

                      <div class="timeline-body">
                        Take me to your leader! <br />
						<!--img src="<?php echo base_url('asset/i/howto-wallet2.jpg')?>" width="100%" height="100%" /-->                      </div>
                      <div class="timeline-footer">
                        
                      </div>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline time label -->
                  <li class="time-label">
                        <span class="bg-green">
                          ขั้นตอนการเติมเงิน True Money
                        </span>
                  </li>
                  <!-- /.timeline-label -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-camera bg-purple"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 2 days ago</span>

                      <h3 class="timeline-header"><a href="#">Admin</a><br />กำลังอัพเดต...</h3>

                      <div class="timeline-body">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                      </div>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <li>
                    <i class="fa fa-clock-o bg-gray"></i>
                  </li>
                </ul>
              </div>
              <!-- /.tab-pane -->

              <div class="tab-pane" id="settings">
                <!-- The timeline -->
                <ul class="timeline timeline-inverse">
                  <!-- timeline time label -->
                  <li class="time-label">
                        <span class="bg-green">
                          เงื่อนไขการให้บริการ
                        </span>
                  </li>
                  <!-- /.timeline-label -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-envelope bg-blue"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 12:05</span>

                      <h3 class="timeline-header"><a href="#">ข้อตกลง</a></h3>

                      <div class="timeline-body">
การใช้งาน ความเร็วอินเตอร์เน็ต ขึ้นอยู่หลายปัจจัย หากเน็ตช้าหรือมีปัญหา กรุณาตรวจสอบปัญหาให้แน่ชัดก่อน ว่าเกิดจากอะไร เเล้วค่อยเเจ้งปัญหามา หากปัญหาเกิดจาก เครื่องหรือพื้นที่ใช้งาน ทางผู้ดูเเลจะไม่สามารถเเก้ไขปัญหาให้ได้ ผู้ดูเเลสามารถแก้ได้เฉพาะปัญหา ที่เกิดจากเซิฟเวอร์เท่านั้น
						</div>
                      <div class="timeline-footer">
                      </div>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-user bg-aqua"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 5 mins ago</span>

                      <h3 class="timeline-header no-border"><a href="#">หมายเหตุ</a></h3>
                      <div class="timeline-body">
กรณีโฮสดับ โดนอุด ต้องรอจนกว่าจะหาโฮสใหม่ได้ จะไม่มีการคืนเงินทุกกรณี

						</div>
                      <div class="timeline-footer">
         
					</div>						  
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline item -->
                  <!-- END timeline item -->
                  <!-- timeline time label -->

                  <!-- /.timeline-label -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-clock-o bg-gray"></i>
                  </li>
                </ul>
              </div>
                  </div>
                </form>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
			

