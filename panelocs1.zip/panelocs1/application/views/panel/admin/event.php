<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper clearfix">
<!-- Main content -->
  <div class="col-md-12 form f-label" >
  <?php if($this->session->flashdata("messagePr")){?>
    <div class="alert alert-info">      
      <?php echo $this->session->flashdata("messagePr")?>
    </div>
  <?php } ?>
        <!-- Profile Image -->
    <div class="box box-success pad-profile">
     	<div class="box-header with-border">
        <h3 class="box-title">Events Settings <small></small></h3>
    </div>
		<div class="box-body box-profile">
  		<div class="row">
        	<div class="col-xs-12">
            <div class="box-header with-border">
       <!-- Profile Image -->   
	   <div class="form-group has-feedback">
    	<div class="col-lg-6">           
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo $error ?></div>
					</div>
			   <?php endif;?>
			   <?php echo form_open() ?>
					<div class="form-group">
						<label for="rekening">Promotion x 2</label>
						<input type="text" name="promox" class="form-control" id="promox" placeholder="ใส่ 1 ปกติ : ใส่ 2 คูณทันที"/>
						<small class="text-muted">ตัวอย่าง :  ระบุเป็นตัวเลขเช่น 1 , 2</small>
					</div>
						<label for="pemilik">หัวข้อของกิจกรรม</label>
						<input type="text" name="rekening" class="form-control" id="rekening" placeholder="ข้อความ"/>
						
						<label for="bank">ข้อมูลของกิจกรรม</label>
						<input type="text" name="bank" class="form-control" id="bank" placeholder="ข้อความ"/>
						<br />
					<div class="form-group">
						<input type="submit" class="button button-border-primary" value="ยืนยัน"/>
					</div>
			   </form>
            </div>
        </div>
        
         <div class="col-lg-6">   
				<?php if (!empty($asset)):?>
								<div class="box box-success pad-profile">
<div class="box-body box-profile">
					<div class="table-responsive">
						<table class="table table-hover">
						<thead>
							<tr><th>#</th><th>โปร x</th><th>หัวข้อ</th><th>ข้อมูล</th></tr>
                        </thead>
                        <tbody>
						<?php foreach ($asset as $row): ?>
							<tr>
								
								<?php if (empty($row['nohp'])):?>
									<?php if (empty($row['webname'])):?>
									<td><a href="<?php echo base_url('admin/del_req/'.$row['id'])?>">Del</a></td>
									<td><?php echo $row['promox']?></td>
									<td><?php echo $row['rekening']?></td>
									<td><?php echo $row['bank']?></td>
									<?php endif;?>
								<?php endif; ?>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table></div>
					<?php else: ?>
						<h4 class="page-header">ยังไม่ได้สร้างกิจกรรมอะไร</h4>
				<?php endif; ?>
			</div>
		</div>
    </div>
    
      </section>
</div>