<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Content Wrapper. Contains page content -->

<div class="content-wrapper clearfix">
<!-- Main content -->
<div class="col-md-12 form f-label" >
<?php if($this->session->flashdata("messagePr")){?>
<div class="alert alert-info"> <?php echo $this->session->flashdata("messagePr")?> </div>
<?php } ?>
<!-- Profile Image -->
<div class="box box-success pad-profile">
<div class="box-header with-border">
  <h3 class="box-title">News Settings <small></small></h3>
</div>
<div class="box-body box-profile">
<div class="row">
<div class="col-xs-12">
<div class="box-header with-border">
  <!-- Profile Image -->
  <div class="form-group has-feedback">
    <div class="col-lg-6">
      <?php if (isset($message)) {echo $message;} ?>
      <?php if (validation_errors()) : ?>
      <div class="col-md-12">
        <div class="alert alert-danger" role="alert"><?php echo validation_errors() ?></div>
      </div>
      <?php endif; ?>
      <?php if (isset($error)) : ?>
      <div class="col-md-12">
        <div class="alert alert-danger" role="alert"><?php echo $error ?></div>
      </div>
      <?php endif;?>
      <?php echo form_open() ?>
      <div class="form-group">
        <label for="rekening">หัวข้อหลัก</label>
        <input type="text" name="news_title" class="form-control" id="news_title" placeholder="ระบุข้อความ..."/>
        <small class="text-muted">ตัวอย่าง : ประกาศ!! </small> </div>
      <label for="pemilik">ข้อมูลข่าวสาร</label>
      <input type="text" name="news_new" class="form-control" id="news_new" placeholder="ข้อความ"/>
      <label for="bank">Social Links</label>
      <input type="text" name="news_data" class="form-control" id="news_data" placeholder="ข้อความ"/>
      <br />
      <div class="form-group">
        <input type="submit" class="button button-border-primary" value="บันทึก"/>
      </div>
      </form>
    </div>
  </div>
  <div class="col-lg-6">
    <?php if (!empty($asset)):?>
    <div class="box box-success pad-profile">
      <div class="box-body box-profile">
        <div class="table-responsive">
          <table class="table table-hover">
            <thead>
              <tr>
                <th>#</th>
                <th>หัวข้อ</th>
                <th>หัวข้อข่าว</th>
                <th>Links</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($asset as $row): ?>
              <tr>
                <?php if (empty($row['nohp'])):?>
                <?php if (empty($row['webname'])):?>
                <td><a href="<?php echo base_url('admin/del_new_news/'.$row['id'])?>">Del</a></td>
                <td><?php echo $row['news_title']?></td>
                <td><?php echo $row['news_new']?></td>
                <td><?php echo $row['news_data']?></td>
                <?php endif;?>
                <?php endif; ?>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php else: ?>
        <h4 class="page-header">ยังไม่มีข่าวใด ๆ</h4>
        <?php endif; ?>
      </div>
    </div>
  </div>
  </section>
</div>
