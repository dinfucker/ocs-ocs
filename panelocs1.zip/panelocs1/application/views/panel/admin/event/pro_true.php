<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Content Wrapper. Contains page content -->

<div class="content-wrapper clearfix">
<!-- Main content -->
<div class="col-md-12 form f-label" >
<?php if($this->session->flashdata("messagePr")){?>
<div class="alert alert-info"> <?php echo $this->session->flashdata("messagePr")?> </div>
<?php } ?>
<!-- Profile Image -->
<div class="box box-success pad-profile">
<div class="box-header with-border">
  <h3 class="box-title">Promotion True <small></small></h3>
</div>
<div class="box-body box-profile">
<div class="row">
<div class="col-xs-12">
<div class="box-header with-border">
  <!-- Profile Image -->
  <div class="form-group has-feedback">
    <div class="col-lg-6">
      <?php if (isset($message)) {echo $message;} ?>
      <?php if (validation_errors()) : ?>
      <div class="col-md-12">
        <div class="alert alert-danger" role="alert"><?php echo validation_errors() ?></div>
      </div>
      <?php endif; ?>
      <?php if (isset($error)) : ?>
      <div class="col-md-12">
        <div class="alert alert-danger" role="alert"><?php echo $error ?></div>
      </div>
      <?php endif;?>
      <?php echo form_open() ?>
      <div class="form-group">
        <label for="rekening">รายละเอียด</label>
        <input type="text" name="t_descrip" class="form-control" id="t_descrip" placeholder="ว่าวโลด..."/>
        <small class="text-muted">ตัวอย่าง : TRUE ID 1 วัน / 9.63บาท +VAT </small> </div>
      <label for="pemilik">เบอร์สมัคร</label>
      <input type="text" name="t_phone" class="form-control" id="t_phone" placeholder="*900*3956*17327707#"/>
      <label for="bank">ลิ้งสมัคร</label>
      <input type="text" name="t_link" class="form-control" id="t_link" placeholder="tel:*900*3956*17327707%23"/>
      <label for="bank">เลือกสีปุ่มกด</label>
              			    <select class="form-control" name="t_button">
              			      <option value="primary">Primary</option>
              			      <option value="success">Success</option>
              			      <option value="info">Info</option>
              			      <option value="warning">Warning</option>
              			      <option value="danger">Danger</option>
							</select>
	  <br />
      <div class="form-group">
        <input type="submit" class="button button-border-primary" value="บันทึก"/>
      </div>
      </form>
    </div>
  </div>
  <div class="col-lg-6">
    <?php if (!empty($asset)):?>
    <div class="box box-success pad-profile">
      <div class="box-body box-profile">
        <div class="table-responsive">
          <table class="table table-hover">
            <thead>
              <tr>
                <th>#</th>
                <th>Descrip</th>
                <th>Phone</th>
                <th>Links</th>
                <th>Button</th>				
              </tr>
            </thead>
            <tbody>
              <?php foreach ($asset as $row): ?>
              <tr>
                <?php if (empty($row['nohp'])):?>
                <?php if (empty($row['webname'])):?>
                <td><a href="<?php echo base_url('admin/del_pro_true/'.$row['id'])?>">Del</a></td>
                <td><?php echo $row['t_descrip']?></td>
                <td><?php echo $row['t_phone']?></td>
                <td><?php echo $row['t_link']?></td>
                <td><?php echo $row['t_button']?></td>				
                <?php endif;?>
                <?php endif; ?>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php else: ?>
        <h4 class="page-header">ยังไม่มีโปรโมชั่นใด ๆ</h4>
        <?php endif; ?>
      </div>
    </div>
  </div>
  </section>
</div>
