<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper clearfix">
<!-- Main content -->
  <div class="col-md-12 form f-label" >
  <?php if($this->session->flashdata("messagePr")){?>
    <div class="alert alert-info">      
      <?php echo $this->session->flashdata("messagePr")?>
    </div>
  <?php } ?>
        <!-- Profile Image -->
    <div class="box box-success pad-profile">
     	<div class="box-header with-border">
        <h3 class="box-title">Add Members <small></small></h3>
    </div>
		<div class="box-body box-profile">
  		<div class="row">
					                <?php if (isset($success)) {echo $success; }?>
			 <?php if (validation_errors()) : ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
			<?php echo  validation_errors() ?>
				</div>
			</div>
			<?php endif; ?>
			
        	<div class="col-xs-12">
            <div class="box-header with-border">
            
			<?php if (isset($error)) : ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
					<?php echo  $error ?>
				</div>
			</div>
			<?php endif; ?>
			
					<div class="form-group has-feedback">
					<?php echo  form_open() ?>
              		<label for="exampleInputEmail1">ชื่อบัญชี:</label>
			  			<input type="text" class="form-control" id="username" name="username" placeholder="อย่างน้อย 4 ตัว">
              		<span class="glyphicon glyphicon-lock form-control-feedback"></span>
            		</div>    
						<?php if (isset($message)) {echo $message; }?><?php if (isset($success)) {echo $success; }?>                   
            		<div class="form-group has-feedback">
              		<label for="exampleInputEmail1">Email:</label>
              			<input type="email" class="form-control" id="email" name="email" placeholder="Email">
              		<span class="glyphicon glyphicon-pencil form-control-feedback"></span>
            		</div>                       
            		<div class="form-group has-feedback">
             		<label for="exampleInputEmail1">รหัสผ่าน:</label>
              			<input type="password" class="form-control" id="password" name="password" placeholder="อย่างน้อย 6 ตัว">
              		<span class="glyphicon glyphicon-pencil form-control-feedback"></span>
            		</div>  
					<div class="form-group has-feedback">
              		<label for="exampleInputEmail1">ยืนยันรหัสผ่าน:</label>
              			<input type="password" class="form-control" id="password_confirm" name="password_confirm" placeholder="ยืนยันรหัส">
              		<span class="glyphicon glyphicon-pencil form-control-feedback"></span>
            </div>  
  									<div class="col-xl-4">
                                    <div align="left">
                                      <button class="btn btn-danger btn-round">ตวรจสอบสมาชิก !</button> 
                                    </div>
									<br>
	
            </div>
			</form>
 </div>
 </div>
 </div> 			
    	</div>
