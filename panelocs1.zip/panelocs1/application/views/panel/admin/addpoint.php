<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper clearfix">
<!-- Main content -->
  <div class="col-md-12 form f-label" >
  <?php if($this->session->flashdata("messagePr")){?>
    <div class="alert alert-info">      
      <?php echo $this->session->flashdata("messagePr")?>
    </div>
  <?php } ?>
    <!-- Profile Image -->
    <div class="box box-success pad-profile">
		<div class="box-body box-profile">
  		<div class="row">
        	<div class="col-xs-12">
            <div class="box-header with-border">
                  <h3 class="box-title">Expired</h3>
                  <div class="input-group text-center">
				  <form action="../addpoints/input.php" method="post"> 
                                </div>
                                <div class="content">                                
                                    <p class="card-content">
                                        ใส่ (username) ที่ต้องการเติมเงิน
                                    </p>
									<div class="input-group text-center">
		<span class="input-group-addon">
		<div align="left">
	<input type="text" placeholder="Username" class="form-control" name="user">
	</div>    
	</div>  
									<br>
									<div class="col-xl-4">
                                    <div align="left">
                                      <button class="button button-3d-caution">ตวรจสอบสมาชิก !</button> 
                                    </div>
									<br>
	
            </div>
			</form>
 </div>
 </div>
 </div> 			
    	</div>