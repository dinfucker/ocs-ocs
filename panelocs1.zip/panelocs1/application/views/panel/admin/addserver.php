<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper clearfix">
<!-- Main content -->
  <div class="col-md-12 form f-label" >
  <?php if($this->session->flashdata("messagePr")){?>
    <div class="alert alert-info">      
      <?php echo $this->session->flashdata("messagePr")?>
    </div>
  <?php } ?>
        <!-- Profile Image -->
    <div class="box box-success pad-profile">
     	<div class="box-header with-border">
        <h3 class="box-title">Add Servers <small></small></h3>
    </div>
		<div class="box-body box-profile">
  		<div class="row">
		<?php if (isset($success)) {echo $success; }?>		
        	<div class="col-xs-12">
            <div class="box-header with-border">
       <!-- Profile Image -->    		
			
					<div class="form-group has-feedback">
					<form action="<?php echo  base_url('index/administrator/'.$_SESSION['username'].'/'.'addserver') ?>" method="POST">
              		<label for="exampleInputEmail1">เซิร์ฟเวอร์:</label>
			  			<input class="form-control" placeholder="ชื่อเซิร์ฟเวอร์" name="ServerName" type="text" required>
              		<span class="glyphicon glyphicon-bookmark form-control-feedback"></span>
            		</div>    
						<?php if (isset($message)) {echo $message; }?><?php if (isset($success)) {echo $success; }?>                   
            		<div class="form-group has-feedback">
              		<label for="exampleInputEmail1">ประเทศ:</label>
              			                            <select class="form-control" name="Location">
								<?php foreach($this->user_model->get_country() as $row):?>
								<option value="<?php echo  $row['Country'] ?>"><?php echo  $row['Country'] ?></option>
								<?php endforeach;?>
							</select>
              		<span class="form-control-feedback"></span>
            		</div>                       
            		<div class="form-group has-feedback">
             		<label for="exampleInputEmail1">IP / Host:</label>
              			<input class="form-control" placeholder="ตัวอย่าง 192.168.1.1" name="HostName" type="text" required>
              		<span class="glyphicon glyphicon-link form-control-feedback"></span>
            		</div>  
					<div class="form-group has-feedback">
              		<label for="exampleInputEmail1">Port SSH:</label>
              			<input class="form-control" placeholder="22" name="OpenSSH" type="text" required>
              		<span class="glyphicon glyphicon-transfer form-control-feedback"></span>
           			 </div>  
					 					<div class="form-group has-feedback">
              		<label for="exampleInputEmail1">Port Dropbear:</label>
              			<input class="form-control" placeholder="443" name="Dropbear" type="text" required>
              		<span class="glyphicon glyphicon-transfer form-control-feedback"></span>
           			 </div> 
					 					<div class="form-group has-feedback">
              		<label for="exampleInputEmail1">จำกัดเชื่อมต่อ SSH:</label>
              			<input class="form-control" placeholder="2" name="limitssh" type="text" required>
              		<span class="glyphicon glyphicon-phone form-control-feedback"></span>
           			 </div> 
					 					<div class="form-group has-feedback">
              		<label for="exampleInputEmail1">จำกัดเชื่อมต่อ VPN:</label>
              			<input class="form-control" placeholder="1" name="limitvpn" type="text" required>
              		<span class="glyphicon glyphicon-phone form-control-feedback"></span>
           			 </div> 
					 					<div class="form-group has-feedback">
              		<label for="exampleInputEmail1">ชื่อไฟล์ SSH:</label>
              			<input class="form-control" placeholder="ตัวอย่าง TH1.MEMBER-VPN.ehi" name="configssh" type="text" required>
              		<span class="glyphicon glyphicon-cloud-download form-control-feedback"></span>
           			 </div> 
					 					<div class="form-group has-feedback">
              		<label for="exampleInputEmail1">ชื่อไฟล์ VPN:</label>
              			<input class="form-control" placeholder="ตัวอย่าง TH1.MEMBER-VPN.ovpn" name="configvpn" type="text" required>
              		<span class="glyphicon glyphicon-cloud-download form-control-feedback"></span>
           			 </div> 
					 					<div class="form-group has-feedback">
              		<label for="exampleInputEmail1">วันใช้งาน:</label>
              			<input class="form-control" placeholder="7" name="Expired" type="text" required>
              		<span class="glyphicon glyphicon-time form-control-feedback"></span>
           			 </div> 
					 					<div class="form-group has-feedback">
              		<label for="exampleInputEmail1">ราคา:</label>
              			<input class="form-control" placeholder="10" name="Price" type="number" step="1" required>
              		<span class="fa fa-credit-card form-control-feedback"></span>
           			 </div> 
					 					<div class="form-group has-feedback">
              		<label for="exampleInputEmail1">รหัสผ่านของ VPS:</label>
              			<input class="form-control" placeholder="r0oT_p4s5wo0rD" name="RootPasswd" type="text">
              		<span class="glyphicon glyphicon-tasks form-control-feedback"></span>
           			 </div> 
  									<div class="col-xl-4">
                                    <div align="left">
                                                              <input type="submit" class="btn btn-primary" value="ยืนยัน">
                        <a href="<?php echo  base_url('index/administrator/'.$_SESSION['username'].'/'.'server') ?>" class="badge bg-orange">ยกเลิก</a>
                    </form> 
                                    </div>
									<br>
	
            </div>
			</form>
 </div>
 </div>
 </div> 			
    	</div>

