<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper clearfix">
<!-- Main content -->
  <div class="col-md-12 form f-label" >
  <?php if($this->session->flashdata("messagePr")){?>
    <div class="alert alert-info">      
      <?php echo $this->session->flashdata("messagePr")?>
    </div>
  <?php } ?>
        <!-- Profile Image -->
    <div class="box box-success pad-profile">
     	<div class="box-header with-border">
        <h3 class="box-title">Contacts Settings <small></small></h3>
    </div>
		<div class="box-body box-profile">
  		<div class="row">
									<?php if (isset($message)) : ?>
									<?php echo  $message ?>
							<?php endif; ?>		
        	<div class="col-xs-12">
            <div class="box-header with-border">
       <!-- Profile Image -->   
	   <div class="form-group has-feedback">
    	<div class="col-lg-6">
                 <div class="form-group">
                    <h3 class="panel-title">แก้ไขข้อมูลเว็บไซต์</h3>
                </div>
                
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  $error ?></div>
					</div>
			   <?php endif;?>
                <?php echo  form_open() ?>
                <div class="form-group">
                   <input type="text" name="webname" class="form-control" id="webname" placeholder="ใส่ชื่อเว็บไซต์"/>
                       </div>
				              <div class="form-group">
                   <input type="text" name="fbchat" class="form-control" id="fbchat" placeholder="Messenger id"/>
                       </div>
					                  <div class="form-group">
                   <input type="text" name="fbface" class="form-control" id="fbface" placeholder="Facebook id"/>
                       </div>
					                  <div class="form-group">
                   <input type="text" name="fbgroup" class="form-control" id="fbgroup" placeholder="Facebook groups id"/>
                       </div>	   
                       <div class="form-group">
						<input type="submit" class="button button-border-primary" value="ยืนยัน"/>
					</div>
                 </form>
            </div>
        </div>
        
         <div class="col-lg-6">   
				<?php if (!empty($asset)):?>
				<div class="box box-success pad-profile">
<div class="box-body box-profile">
					<div class="table-responsive"><table class="table table-hover">
						<thead>
							<tr>
							<th>Webname</th>
							<th>Messenger</th>
							<th>Facebook</th>
							<th>Fb Groups</th>
							</tr>
                        </thead>
                        <tbody>
						<?php foreach ($asset as $row): ?>
							<?php if (empty($row['rekening'])):?>
                          		<?php if (empty($row['bank'])):?>
                             		<?php if (empty($row['pemilik'])):?>
							<tr>
								<td><a href="<?php echo base_url('admin/del_req/'.$row['id'])?>">Del</a></td>
								<td><?php echo  $row['webname']?></td>
								<td><?php echo  $row['fbchat']?></td>
								<td><?php echo  $row['fbface']?></td>
								<td><?php echo  $row['fbgroup']?></td>
							</tr>
									<?php endif;?>
							    <?php endif;?>
    						<?php endif;?>
						<?php endforeach; ?>
						</tbody>
					</table></div>
					<?php else: ?>
						<h4 class="page-header">ยังไม่ได้ตั้งไว้</h4>
				<?php endif; ?>
			</div>
		</div>
    </div>
    
      </section>
</div>