<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper clearfix">
<!-- Main content -->
  <div class="col-md-12 form f-label" >
  <?php if($this->session->flashdata("messagePr")){?>
    <div class="alert alert-info">      
      <?php echo $this->session->flashdata("messagePr")?>
    </div>
  <?php } ?>
        <!-- Profile Image -->
    <div class="box box-success pad-profile">
     	<div class="box-header with-border">
        <h3 class="box-title">Links Settings <small></small></h3>
    </div>
		<div class="box-body box-profile">
  		<div class="row">	
        	<div class="col-xs-12">
            <div class="box-header with-border">
       <!-- Profile Image -->   
	   <div class="form-group has-feedback">
    	<div class="col-lg-6">
                 <div class="form-group">
                    <h3 class="panel-title">เพิ่มไฟล์ vpn ehi ...</h3>
                </div>
                
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  $error ?></div>
					</div>
			   <?php endif;?>
                <?php echo  form_open() ?>
                <div class="form-group">
                   <input type="text" name="file_name" class="form-control" id="file_name" placeholder="ชื่อเซิร์ฟเวอร์"/>
                       </div>
				              <div class="form-group">
                   <input type="text" name="file_sim" class="form-control" id="file_sim" placeholder="ซิมอะไร"/>
                       </div>
					                  <div class="form-group">
                   <input type="text" name="file_pro" class="form-control" id="file_pro" placeholder="โปรอะไร"/>
                       </div>
					                  <div class="form-group">
                   <input type="text" name="file_ovpn" class="form-control" id="file_ovpn" placeholder="ลิ้งค์ดาวน์โหลด OPENVPN หรือ .ovpn"/>
                       </div>	  
				              <div class="form-group">
                   <input type="text" name="file_ehi" class="form-control" id="file_ehi" placeholder="ลิ้งค์ดาวน์โหลด MAX Speed หรือ .ehi"/>
                       </div>					    
                       <div class="form-group">
						<input type="submit" class="button button-border-primary" value="ยืนยัน"/>
					</div>
                 </form>
            </div>
        </div>
        
         <div class="col-lg-6">   
				<?php if (!empty($asset)):?>
				<div class="box box-success pad-profile">
<div class="box-body box-profile">
					<div class="table-responsive"><table class="table table-hover">
						<thead>
							<tr>
							<th></th>
							<th>Server</th>
							<th>Sim</th>
							<th>Pro</th>
							<th>Ovpn</th>
							<th>Ehi</th>							
							</tr>
                        </thead>
                        <tbody>
						<?php foreach ($asset as $row): ?>
							<?php if (empty($row['rekening'])):?>
                          		<?php if (empty($row['bank'])):?>
                             		<?php if (empty($row['pemilik'])):?>
							<tr>
								<td><a href="<?php echo base_url('admin/del_all_filesvpn/'.$row['id'])?>">Del</a></td>
								<td><?php echo  $row['file_name']?></td>
								<td><?php echo  $row['file_sim']?></td>
								<td><?php echo  $row['file_pro']?></td>
								<td><?php echo  $row['file_ovpn']?></td>
								<td><?php echo  $row['file_ehi']?></td>								
							</tr>
									<?php endif;?>
							    <?php endif;?>
    						<?php endif;?>
						<?php endforeach; ?>
						</tbody>
					</table></div>
					<?php else: ?>
						<h4 class="page-header">ยังไม่ได้ตั้งไว้</h4>
				<?php endif; ?>
			</div>
		</div>
    </div>
    
      </section>
</div>