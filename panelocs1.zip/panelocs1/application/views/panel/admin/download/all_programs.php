<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper clearfix">
<!-- Main content -->
  <div class="col-md-12 form f-label" >
  <?php if($this->session->flashdata("messagePr")){?>
    <div class="alert alert-info">      
      <?php echo $this->session->flashdata("messagePr")?>
    </div>
  <?php } ?>
        <!-- Profile Image -->
    <div class="box box-success pad-profile">
     	<div class="box-header with-border">
        <h3 class="box-title">Links Settings <small></small></h3>
    </div>
		<div class="box-body box-profile">
  		<div class="row">	
        	<div class="col-xs-12">
            <div class="box-header with-border">
       <!-- Profile Image -->   
	   <div class="form-group has-feedback">
    	<div class="col-lg-6">
                 <div class="form-group">
                    <h3 class="panel-title">แก้ไขลิ้งค์ดาวน์โหลด</h3>
                </div>
                
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  $error ?></div>
					</div>
			   <?php endif;?>
                <?php echo  form_open() ?>
                <div class="form-group">
                   <input type="text" name="pritunl" class="form-control" id="pritunl" placeholder="โปรแกรม Pritunl"/>
                       </div>
				              <div class="form-group">
                   <input type="text" name="pcvpn" class="form-control" id="pcvpn" placeholder="โปรแกรม OpenVPN"/>
                       </div>
					                  <div class="form-group">
                   <input type="text" name="appvpn" class="form-control" id="appvpn" placeholder="แอป Openvpn"/>
                       </div>
					                  <div class="form-group">
                   <input type="text" name="apphttp" class="form-control" id="apphttp" placeholder="แอป HTTP Injector"/>
                       </div>	   
                       <div class="form-group">
						<input type="submit" class="button button-border-primary" value="ยืนยัน"/>
					</div>
                 </form>
            </div>
        </div>
        
         <div class="col-lg-6">   
				<?php if (!empty($asset)):?>
				<div class="box box-success pad-profile">
<div class="box-body box-profile">
					<div class="table-responsive"><table class="table table-hover">
						<thead>
							<tr>
							<th></th>							
							<th>Pritunl</th>
							<th>OpenVPN</th>
							<th>App VPN</th>
							<th>App HTTP</th>
							</tr>
                        </thead>
                        <tbody>
						<?php foreach ($asset as $row): ?>
							<?php if (empty($row['rekening'])):?>
                          		<?php if (empty($row['bank'])):?>
                             		<?php if (empty($row['pemilik'])):?>
							<tr>
									<td><a href="<?php echo base_url('admin/del_all_programs/'.$row['id'])?>">ลบ</a></td>
								<td><?php echo  $row['pritunl']?></td>
								<td><?php echo  $row['pcvpn']?></td>
								<td><?php echo  $row['appvpn']?></td>
								<td><?php echo  $row['apphttp']?></td>
							</tr>
									<?php endif;?>
							    <?php endif;?>
    						<?php endif;?>
						<?php endforeach; ?>
						</tbody>
					</table></div>
					<?php else: ?>
						<h4 class="page-header">ยังไม่ได้ตั้งไว้</h4>
				<?php endif; ?>
			</div>
		</div>
    </div>
    
      </section>
</div>