<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper clearfix">
<!-- Main content -->
  <div class="col-md-12 form f-label" >
  <?php if($this->session->flashdata("messagePr")){?>
    <div class="alert alert-info">      
      <?php echo $this->session->flashdata("messagePr")?>
    </div>
  <?php } ?>
        <!-- Profile Image -->
    <div class="box box-success pad-profile">
     	<div class="box-header with-border">
        <h3 class="box-title">Add Truewallet <small></small></h3>
    </div>
		<div class="box-body box-profile">
  		<div class="row">
		<?php if (isset($success)) {echo $success; }?>		
        	<div class="col-xs-12">
            <div class="box-header with-border">
       <!-- Profile Image -->   
    
    
         <div class="col-sm-12">
         	<center>
			<br />
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-green">เพิ่มข้อมูลสำหรับการโอน</span></span>         
           </center> 
		   <br>          
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo $error ?></div>
					</div>
			   <?php endif;?>
			   <?php echo form_open() ?>
					<div class="form-group">
						<label for="pemilik">ชื่อ Wallet</label>
						<input type="text" name="pemilik" class="form-control" id="pemilik" placeholder="User"/>
					</div>
					
						<label for="nohp">เบอร์ Wallet</label>
						<input type="text" name="nohp" class="form-control" id="nohp" placeholder="Phone"/>
					
						<label for="provider">ระบบ SIM</label>
						<select name="provider" class="form-control">
							<option value="TRUE">TRUE</option>
							<option value="DTAC">DTAC</option>
							<option value="AIS">AIS</option>
						</select>
					<br />
					<div class="form-group">
              <button type="submit" class="button button-border-primary" data-toggle="modal" data-target="#modal-danger">บันทึก</button> 
			  <button type="reset" class="button button-border-caution">ยกเลิก</button>
					</div>
			   </form>
	      </div>
		</div>
		    			<div class="col-sm-12">
					<div class="panel-body">
						<?php if (!empty($asset)):?>
							<div class="table-responsive">
								<table class="table table-hover">
								
								<thead>
							<tr><th>#</th><th>ชื่อ</th><th>เบอร์</th><th>SIM</th></tr>
                        </thead>
                        <tbody>
						<?php foreach ($asset as $row): ?>
							<tr>
									<?php if (empty($row['rekening'])):?>
									<?php if (empty($row['webname'])):?>
									<td><a href="<?php echo base_url('admin/del_hp/'.$row['id'])?>">ลบ</a></td>
									<td><?php echo $row['pemilik'] ?></td>
									<td><?php echo $row['nohp']?></td>
									<td><?php echo $row['provider']?></td>
									<?php endif; ?>
								<?php endif; ?>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					</div>
					<?php else: ?>
						<h4 class="page-header">ไม่มีการตั้งค่า</h4>
				<?php endif; ?>
			</div>
   	</div>
    </div>
		
		
      </section>
</div>