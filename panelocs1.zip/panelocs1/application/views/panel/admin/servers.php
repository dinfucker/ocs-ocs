<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper clearfix">
<!-- Main content -->
  <div class="col-md-12 form f-label" >
  <?php if($this->session->flashdata("messagePr")){?>
    <div class="alert alert-info">      
      <?php echo $this->session->flashdata("messagePr")?>
    </div>
  <?php } ?>
        <!-- Profile Image -->
    <div class="box box-success pad-profile">
     	<div class="box-header with-border">
        <h3 class="box-title">Add Servers <small></small></h3>
    </div>
		<div class="box-body box-profile">
  		<div class="row">
		<?php if (isset($success)) {echo $success; }?>		
        	<div class="col-xs-12">
            <div class="box-header with-border">
       <!-- Profile Image -->   
                <?php if (isset($_SESSION['is_admin'])): ?>
                <a href="<?php echo  base_url('index/administrator/'.str_replace(' ','-',$_SESSION['username']).'/addserver') ?>" class="button button-3d pull-right"><i class="fa fa-plus fa-fw"></i> เพิ่มเซิร์ฟเวอร์ </a>
                <?php endif; ?>           
    <br><br><br>
    <div class="row">
            <div class="col-lg-12">
                <?php if (isset($message)) { echo $message;} ?>
            </div>
        <?php foreach($server as $row): ?>
            <div class="col-sm-6 col-md-4 col-lg-4">				 
<div class="box box-info pad-profile">
     	<div class="box-header with-border">                     
												<div class="panel-title"><b><?php echo  $row['ServerName']?></b></div>
							<span clas="pull-right">
							<?php if ($row['Status']): ?>
								<a class="button button-circle button-flat-action button-tiny pull-right" href="<?php echo  base_url('index/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'].'/lock' ) ?>"><i class="fa fa-unlock"></i> เปิดบริการ</a>
								<?php else: ?>
								<a class="button button-circle button-flat-caution button-tiny pull-right" href="<?php echo  base_url('index/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'].'/unlock' ) ?>"><i class="fa fa-lock"></i>  ปิดบริการ</a>
								<?php endif; ?>
							</span>
                    </div>
                    <div class="panel-body">
                    <table class="table table-condensed">
                        <tr>
                            <td>Server</td><td><?php echo  $row['Location']?></td>
                        </tr>
                        <tr>
                            <td>Host</td><td><?php echo  $row['HostName']?></td>
                        </tr>
                        <tr>
                            <td>ราคา</td><td><?php echo  $row['Price']?></td>
                        </tr>
                    </table>  
                    </div>
						
                    <div class="box-footer text-center">
                        <a href="<?php echo  base_url('index/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'])?>" class="button button-flat-primary button-small"><i class="fa fa-edit fa-fw"></i> แก้ไข</a>
                        <a href="<?php echo  base_url('admin/usercheck/'.$row['Id']) ?>" class="button button-flat-highlight button-small"><i class="fa fa-group fa-fw"></i> เช็ค</a>
                        <a href="<?php echo  base_url('index/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'].'/del' ) ?>" class="button button-flat-caution button-small">ลบ</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
      </section>
</div>