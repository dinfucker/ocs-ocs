<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper clearfix">
<!-- Main content -->
  <div class="col-md-12 form f-label" >
  <?php if($this->session->flashdata("messagePr")){?>
    <div class="alert alert-info">      
      <?php echo $this->session->flashdata("messagePr")?>
    </div>
  <?php } ?>
        <!-- Profile Image -->
    <div class="box box-success pad-profile">
     	<div class="box-header with-border">
        <h3 class="box-title">Add Servers <small></small></h3>
    </div>
		<div class="box-body box-profile">
  		<div class="row">
									<?php if (isset($message)) : ?>
									<?php echo  $message ?>
							<?php endif; ?>		
        	<div class="col-xs-12">
            <div class="box-header with-border">
       <!-- Profile Image -->   
	   <div class="form-group has-feedback">
	   <form action="<?php echo  base_url('index/administrator/edit/'.str_replace(' ','-',$server -> ServerName).'/'.$server->Id ) ?>" method="POST">
								<div class="form-group">
									<label for="ServerName">ชื่อเซิร์ฟเวอร์</label>
									<input type="text" class="form-control" id="ServerName" name="ServerName" value="<?php echo  $server -> ServerName ?>">
									
								</div>
								<div class="form-group">
									<label for="sel1">Location :</label>
									<select class="form-control" id="sel1" name="Location">
										<option value="<?php echo  $server->Location ?>" selected="<?php echo  $server->Location ?>"><?php echo  $server->Location ?></option>
										<?php foreach($this->user_model->get_country() as $row):?>
										<option value="<?php echo  $row['Country'] ?>"><?php echo  $row['Country'] ?></option>
										<?php endforeach;?>
									</select>
									
								</div>
								<div class="form-group">
									<label for="email">ราคา</label>
									<input type="number" class="form-control" id="email" name="Price" value="<?php echo  $server->Price ?>">
									
								</div>
								<div class="form-group">
									<label for="email">Hostname</label>
									<input type="text" class="form-control" id="email" name="HostName" value="<?php echo  $server->HostName ?>">
								
								</div>
								<div class="form-group">
									<label for="password_confirm">RootPasswd</label>
									<input type="password" class="form-control" id="password_confirm" name="RootPasswd" value="<?php echo  $server->RootPasswd ?>">
								</div>
								<div class="col-xs-6">
									<div class="form-group">
										<label for="password_confirm">จำกัดการเช่า/ต่อวัน</label>
										<input type="number" class="form-control" id="password_confirm" name="MaxUser" value="<?php echo  $server->MaxUser ?>">
									</div>
								</div>			
								<div class="col-xs-6">
									<div class="form-group">
										<label for="password_confirm">วันใช้งาน</label>
										<input type="number" class="form-control" id="password_confirm" name="Expired" value="<?php echo  $server->Expired ?>">
									</div>
								</div>
								<div class="col-xs-6">
									<div class="form-group">
										<label for="password_confirm">Openssh</label>
										<input type="text" class="form-control" id="password_confirm" name="OpenSSH" value="<?php echo  $server->OpenSSH ?>">
										<p class="help-block">หากมากกว่า 1 พอร์ตให้ใส่ (,) คั่นไว้</p>
									</div>
								</div>
								<div class="col-xs-6">
									<div class="form-group">
										<label for="password_confirm">Dropbear</label>
										<input type="text" class="form-control" id="password_confirm" name="Dropbear" value="<?php echo  $server->Dropbear?>">
										<p class="help-block"> หากมากกว่า 1 พอร์ตให้ใส่ (,) คั่นไว้</p>
									</div>
								</div>
								<div class="form-group">
									<input type="submit" class="btn btn-primary" value="ยืนยัน">									
									<a href="<?php echo  base_url('index/administrator/'.$_SESSION['username'].'/'.'server') ?>" class="btn btn-danger">ยกเลิก</a>
								</div>
							</form>
						</div>
					</div>
				</div></div><!-- .row -->
		</div>