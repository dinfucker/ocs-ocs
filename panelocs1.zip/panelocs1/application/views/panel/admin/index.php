﻿<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-home" aria-hidden="true"></i> Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url('index')?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Timeline</li>
      </ol>
    </section>
	
<section class="content">
  <div class="row">
     <div class="col-md-6 col-md-6 col-xs-12">
         <div class="info-box bg-light">
            <span class="info-box-icon"><i class="glyphicon glyphicon-user"></i></span>
            <div class="info-box-content">
               <span class="info-box-text">USERNAME <span class="info-box-text pull-right"> ทั้งหมด </span></span> 
               <span class="info-box-number">สมาชิก <span class="info-box-number pull-right"><?php echo $count_user; ?> ไอดี</span></span>
               <div class="progress">
                  <div class="progress-bar" style="width: 0%"></div>
               </div>
               <span class="progress-description">
                <a href="<?php echo base_url('useronline')?>"> Detials <i class="fa fa-shield"></i></a>
               </span>
            </div>
         </div>
      </div>
     <div class="col-md-6 col-md-6 col-xs-12">
         <div class="info-box bg-light">
            <span class="info-box-icon"><i class="glyphicon glyphicon-th-large"></i></span>
            <div class="info-box-content">
               <span class="info-box-text">SERVERS <span class="info-box-text pull-right"> ทั้งหมด </span></span> 
               <span class="info-box-number">เซิฟเวอร์ <span class="info-box-number pull-right"><?php echo $count_server; ?> เซิฟร์</span></span>
               <div class="progress">
                  <div class="progress-bar" style="width: 0%"></div>
               </div>
               <span class="progress-description">
                <a href="<?php echo base_url('index/administrator/admin/server')?>"> Detials <i class="fa fa-shield"></i></a>
               </span>
            </div>
         </div>
      </div>	
     <div class="col-md-6 col-md-6 col-xs-12">
         <div class="info-box bg-light">
            <span class="info-box-icon"><i class="	fa fa-google-wallet"></i></span>
            <div class="info-box-content">
               <span class="info-box-text">TRUEWALLET <span class="info-box-text pull-right"> จำนวน </span></span> 
               <span class="info-box-number">เติมเงิน <span class="info-box-number pull-right"><?php echo $count_wallet; ?> บาท</span></span>
               <div class="progress">
                  <div class="progress-bar" style="width: 0%"></div>
               </div>
               <span class="progress-description">
                <a href="<?php echo base_url('truewallet')?>"> Detials <i class="fa fa-shield"></i></a>
               </span>
            </div>
         </div>
      </div>	      
     <div class="col-md-6 col-md-6 col-xs-12">
         <div class="info-box bg-light">
            <span class="info-box-icon"><i class="	fa fa-credit-card"></i></span>
            <div class="info-box-content">
               <span class="info-box-text">TRUEMONEY <span class="info-box-text pull-right"> ยอดเติม </span></span> 
               <span class="info-box-number">เติมเงิน <span class="info-box-number pull-right"><?php echo $count_money; ?> บาท</span></span>
               <div class="progress">
                  <div class="progress-bar" style="width: 0%"></div>
               </div>
               <span class="progress-description">
                <a href="<?php echo base_url('truemoney')?>"> Detials <i class="fa fa-shield"></i></a>
               </span>
           </div>
         </div>
      </div>
      <div class="col-md-6 col-md-6 col-xs-12">
         <div class="info-box bg-dark">
            <span class="info-box-icon"><i class="fa fa-css3"></i></span>
           <div class="info-box-content">
               <span class="info-box-text">ยอดขายทั้งหมด</span>
               <span class="info-box-number"><?php echo $count_ssh; ?> บาท</span>
               <div class="progress">
                  <div class="progress-bar" style="width: 100%"></div>
               </div>
              <span class="progress-description">
              <a href="<?php echo base_url('index/administrator/admin/addserver')?>"> <i class="fa fa-plus-square pull-right">  เพิ่มเซิฟเวอร์ </i></a>
              <a href="<?php echo base_url('admin/register/admin')?>"> <i class="fa fa-plus-square pull-left"> เพิ่มสมาชิก </i></a>              </span>            </div>
         </div>
      </div>
	</div>
	</section>





  
  </div>