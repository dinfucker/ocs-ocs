<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper clearfix">
<!-- Main content -->
  <div class="col-md-12 form f-label">
  <?php if($this->session->flashdata("messagePr")){?>
    <div class="alert alert-info">      
      <?php echo $this->session->flashdata("messagePr")?>
    </div>
  <?php } ?>
    <!-- Profile Image -->
    <div class="box box-success pad-profile">
     	<div class="box-header with-border">
        <h3 class="box-title">My Account <small></small></h3>
    </div>

        <div class="box-body box-profile">
          <div class="col-md-3">
            <div class="pic_size" id="image-holder"> 
              <center> <img src="<?php echo base_url().'asset/img/user/u6.png' ?>" alt="User profile picture" width="200" height="200" class="thumb-image setpropileam">
              </center>
            </div>
            <br>
            <center><div class="fileUpload btn btn-success wdt-bg">
                <span><?php echo  $user->email ?></span>
            </div><center>
          </div>
		  
          <div class="col-md-8">
            <h3>Change Password:</h3>
                                <form role="form" action="<?= base_url('index/'.$_SESSION['username'].'/setting')?>" method="POST">
								<input type="hidden" name="username" value="<?= $_SESSION['username'] ?>">
					<div class="form-group has-feedback">
              <label for="exampleInputEmail1">Current Password:</label>
			  <input class="form-control" placeholder="********" name="oldpass" type="password" required>
              <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            </div>    
			<?php if (isset($message)) {echo $message; }?><?php if (isset($success)) {echo $success; }?>                   
            <div class="form-group has-feedback">
              <label for="exampleInputEmail1">New Password:</label>
              <input type="password" class="form-control" placeholder="New Password" name="password" required>
              <span class="glyphicon glyphicon-pencil form-control-feedback"></span>
            </div>                       
            <div class="form-group has-feedback">
              <label for="exampleInputEmail1">Confirm New Password:</label>
              <input type="password" class="form-control" placeholder="Confirm New Password" name="passconf" required>
              <span class="glyphicon glyphicon-pencil form-control-feedback"></span>
            </div>  
            <br>
            <div class="form-group has-feedback sub-btn-wdt" >
              <button type="button" class="button button-flat-primary" data-toggle="modal" data-target="#modal-danger">บันทึก</button> 
			  <button type="reset" class="button button-flat-caution">ยกเลิก</button>
              <!-- <div class=" pull-right">
			  
              </div> -->
			  <div class="modal modal-danger fade" id="modal-danger">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span></button>
<h4 class="modal-title">แจ้งเตือนการเปลี่ยนรหัสผ่าน</h4>
</div>
<div class="modal-body">
<p>กรุณาเช็ครหัสก่อนที่จะกดยืนยัน</p>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-outline pull-left" data-dismiss="modal">ยกเลิก</button>
<button type="submit" class="btn btn-outline">ยืนยัน</button>
</div>
            </div>
          </div>
         <!-- /.box-body -->
        </div>
      </form>                     
      <!-- /.box -->
    </div>
    <!-- /.content -->
  </div>
</div>
<!-- /.content-wrapper -->