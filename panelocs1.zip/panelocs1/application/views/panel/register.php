<body id="page-top" style="height: auto;">




    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="LIFESTYLE VPN">
    <meta name="author" content="LIFESTYLE VPN.GA">
    <title>LIFESTYLE VPN</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/animate.min.css" type="text/css">
    <link rel="stylesheet" href="css/creative.css" type="text/css">
	<!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href="<?php echo  base_url('asset/font-awesome/css/font-awesome.min.css')?>" rel="stylesheet"/>
    <!-- Plugin CSS -->
    <link href="<?php echo  base_url('asset/css/animate.min.css" type="text/css')?>" rel="stylesheet"/>
    <!-- Custom CSS -->
    <link href="<?php echo  base_url('asset/css/creative.css" type="text/css')?>" rel="stylesheet"/>
  	
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
		<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
		
   
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="img/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
  
    <meta name="theme-color" content="#ffffff">


   
<br><br>
	<section id="services">
         <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    
					  <img class="img-circle" src="<?php echo  base_url('asset/img/icon/i3.png') ?>" width="100" height="97">
						  <h2 style='color:#000033'><b>LIFESTYLE VPN</b></h2>
                    <span style="font-size: 21px;" class="badge bg-dark">
         <b>ยินดีต้อนรับ</b>
</div>
</div>
</div><br>
<div class="container">
<div class="row">
<div class="col-md-4 col-md-offset-4">
<div class="col-md-12">
				<?php if (validation_errors()) : ?>
				<div class="alert alert-danger" role="alert">
					<?php echo  validation_errors() ?>
				</div>
			</div>
		<?php endif; ?>
		<?php if (isset($error)) : ?>
				<div class="alert alert-danger" role="alert">
					<?php echo  $error ?>
				</div>
			</div>
		<?php endif; ?>
		
			<?php echo  form_open() ?>
					<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
<input required="required" id="username" type="text" class="form-control" onBlur="checkText();" name="username" value="" placeholder="ใส่ไอดี ของคุณอย่างน้อย 6 ตัว" minlength="3">
</div>
  <div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
<input required="required" id="Email" type="email" class="form-control" onBlur="checkText();" name="email" value="" placeholder="ใส่อีเมล์ ของคุณ" minlength="3">
</div>
  <div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-retweet"></i></span>
<input required="required" id="password" type="password" class="form-control" onBlur="checkText();" name="password" value="" placeholder="ใส่รหัสผ่านอย่างน้อย 6 ตัว" minlength="3">
</div>
<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
<input required="required" id="password_confirm" type="password" class="form-control" onBlur="checkText();" name="password_confirm" value="" placeholder="ใส่รหัสผ่านอีกครั้ง" minlength="3">
</div>
  <div class="form-group">
                                            <button type="submit" name="submit" class="btn btn-success pull-left">
                                            <i class="fa fa fa-check-square-o">
											</i> ยืนยันการสมัคร
                                            </button>
                                            <a href="/" class="btn btn-danger pull-right">
                                                <i class="fa fa-unlock">
												</i> เข้าสู่ระบบ
                                            </a>
                                        </div>
                                    </div>
                                </div></div><br>
	
  


</body>