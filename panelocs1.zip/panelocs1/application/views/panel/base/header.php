<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en" style="height: auto;">

	<head>
  	    <meta charset="utf-8">
  		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="stats-in-th" content="61de" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<meta name="description" content="??????? By : Ocspael.info"/>
		<meta name="keywords" content="Openvpn,vpn,nerfree,nettrue"/>
		<meta name="author" content="www.Ocspael.info"/>
		<title>LIFESTYLE-VPN : บริการอินเตอร์เน็ตระบบ VPN ความเร็วสูง ไม่จำกัดแบนวิท ดูแลตลอดอายุการใช้งาน</title>
		<!-- core CSS -->
	
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
		<link href="<?= base_url('asset/css/sb-admin-2.css')?>" rel="stylesheet"/>
		<link href="<?= base_url('asset/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet"/>
		<link href="<?= base_url('asset/css/bootstrap-dialog.min.css')?>" rel="stylesheet"/>
		<link href="https://cdnjs.cloudflare.com/ajax/libs/metisMenu/2.0.0/metisMenu.min.css">
		<link href="//netdna.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.css" rel="stylesheet">
		<link rel="stylesheet" href="<?php echo base_url('asset/css/buttons.css')?>">
		<LINK REL="SHORTCUT ICON" HREF="<?php echo  base_url('asset/img/icon/i5.png') ?>"
		<script src="<?= base_url('js/jquery.js')?>"></script>
		<!--[if lt IE 9]>
		<script src="<?= base_url('asset/js/html5shiv.js');?>"></script>
		<script src="<?= base_url('asset/js/respond.min.js');?>"></script>
		<![endif]-->
		
	</head>
	<body>
