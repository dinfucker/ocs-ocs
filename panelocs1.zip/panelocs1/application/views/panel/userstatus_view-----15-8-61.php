<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper clearfix">
<!-- Main content -->
  <div class="col-md-12 form f-label" >
  <?php if($this->session->flashdata("messagePr")){?>
    <div class="alert alert-info">      
      <?php echo $this->session->flashdata("messagePr")?>
    </div>
  <?php } ?>
    <!-- Profile Image -->
    <div class="box box-success pad-profile">
		<div class="box-body box-profile">
  		<div class="row">
        	<div class="col-xs-12">
            <div class="box-header with-border">
                  <h3 class="box-title">Expired</h3>
                  <div class="box-tools">
				          <?php 
        $attr = array("class" => "form-horizontal", "role" => "form", "id" => "form1", "name" => "form1");
        echo form_open("userstatus/search", $attr);?>
				                      <input class="form-control" id="book_name" name="book_name" placeholder="Search for Book Name..." type="hidden" value="<?php echo $_SESSION['username'] ?>" />
    <button type="submit" class="btn-sm  btn btn-success modalButtonUser" data-toggle="modal"><i class="fa fa-check-square-o"></i> Show Me</button>                    
	<a href="<?php echo base_url(). "index.php/userstatus/index"; ?>" class="btn-sm  btn btn-info InviteUser"><i class="fa fa-check-square-o"></i> Show All </a>
                    
                  </div>
              </div>
                <!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="cell-border example1 table table-striped table1 delSelTable">
                    <thead>
                    <tr>
                    <th>No</th>
                    <th>User Name</th>
					<th>hostname</th>
                    <th>Expired</th>
			
                    </tr>
                    </thead>
                    <tbody>
					                <?php for ($i = 0; $i < count($booklist); ++$i) { ?>
                <tr>
                    <td><?php echo ($page+$i+1); ?></td>
       
					<td><?php echo $booklist[$i]->username; ?></td>
					<td><?php echo $booklist[$i]->hostname; ?></td>
                    <td><?php  $today=date('Y-m-d'); $expire=date('Y-m-d', strtotime($booklist[$i]->created_at. '+30 days')); if ($today>=$expire){ echo $expire; } else{ echo $expire; } ?></td>
	
					
                </tr>
                <?php } ?>
                    </tbody>
                  </table>
				          </div>
    </div>
    
    <div class="row">
        	<div class="col-xs-12">
            <div class="box-header with-border">
            <center><?php echo $pagination; ?><center>
 </div>
 </div>
 </div> 			
    	</div>