  <div class="content-wrapper" style="min-height: 643px;">
    <section class="content-header">
            <h1>
        <strong> บัญชีทั้งหมด</strong>
      </h1>
            <ol class="breadcrumb">
                <li><a href="/index"><i class="fa fa-fort-home"></i> หน้าหลัก </a></li>
                <li>บัญชีทั้งหมด </li>
            </ol>
        </section>

        <section class="content">

            <div class="row">
                <div class="col-md-12">
                    <div class="box box-widget widget-user">
                        <div class="widget-user-header bg-black" style="background: url('/asset/img/Background/Background2.png') center center;">
                            <h3 class="widget-user-username"><b>รายชื่อบัญชีทั้งหมด<b></b></b></h3><b><b>
                            
                            <a href="/index" class="btn btn-default pull-right waves-effect waves-light"><i class="fa fa-arrow-left"></i> BACK </a>
							<a href="/servers" class="btn btn-primary pull-left waves-effect waves-light"><i class="fa fa-fort-awesome"></i> SERVER </a>
                        </b></b></div><b><b>
                        <div class="widget-user-image">
                            <img class="img-circle" src="https://lifestyle-vpn.tk/asset/img/user/u5.jpg" alt="User Avatar">
                        </div>
                        <div class="box-footer">
                            <div class="row">
                                <div class="col-md-12 border-right">
                                    <center> <form action="/userstatus/search" class="form-horizontal" role="form" id="form1" name="form1" method="post" accept-charset="utf-8">
				                      <input class="form-control" id="book_name" name="book_name" placeholder="Search for Book Name..." type="hidden" value="<?php echo $_SESSION['username'] ?>">
    <button type="submit" class="btn-sm  btn btn-success modalButtonUser" data-toggle="modal"><i class="fa fa-check-square-o"></i> บัญชีของฉัน</button>                    
	<a href="/userstatus/index" class="btn-sm  btn btn-info InviteUser"><i class="fa fa-check-square-o"></i> บัญชีทั้งหมด </a>
 </form></center>
                                           
                     </div>
              </div>
                <!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="cell-border example1 table table-striped table1 delSelTable">
                    <thead>
                    <tr>
                    <th>ชื่อบัญชี</th>
					<th>IP HOST</th>
                    <th>วันหมดอายุ</th>
                    </tr>
                    </thead>
					<?php for ($i = 0; $i < count($booklist); ++$i) { ?>
                    <tbody>
					<tr>     
                    <td><?php echo $booklist[$i]->username; ?></td>
					<td><?php echo $booklist[$i]->hostname; ?></td>
                    <td><?php  $today=date('Y-m-d'); $expire=date('Y-m-d', strtotime($booklist[$i]->created_at. '+30 days')); if ($today>=$expire){ echo $expire; } else{ echo $expire; } ?></td>
                </tr>
    			<?php } ?>
                                    </tbody>
                  </table>
				          </div>
    </div>
    
    <div class="row">
        	<div class="col-xs-12">
            <div class="box-header with-border">
            <center><?php echo $pagination; ?><center>
 </div>
 </div>
 </div> 		</div>
 </div> </div>
 </div> 	
    	