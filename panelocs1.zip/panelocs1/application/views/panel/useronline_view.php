<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper clearfix">
<!-- Main content -->
  <div class="col-md-12 form f-label" >
  <?php if($this->session->flashdata("messagePr")){?>
    <div class="alert alert-info">      
      <?php echo $this->session->flashdata("messagePr")?>
    </div>
  <?php } ?>
    <!-- Profile Image -->
    <div class="box box-success pad-profile">
		<div class="box-body box-profile">
  		<div class="row">
        	<div class="col-xs-12">
            <div class="box-header with-border">
                  <h3 class="box-title">User</h3>
                  <div class="box-tools">
				          <?php 
        $attr = array("class" => "form-horizontal", "role" => "form", "id" => "form1", "name" => "form1");
        echo form_open("useronline/search", $attr);?>
				                      <input class="form-control" id="book_name" name="book_name" placeholder="Search for Book Name..." type="hidden" value="Online" />
    <button type="submit" class="btn-sm  btn btn-success modalButtonUser" data-toggle="modal"><i class="fa fa-check-square-o"></i> Online</button>                    
	<a href="<?php echo base_url(). "index.php/useronline/index"; ?>" class="btn-sm  btn btn-info InviteUser"><i class="fa fa-check-square-o"></i> Offline </a>
                    
                  </div>
              </div>
                <!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="cell-border example1 table table-striped table1 delSelTable">
                    <thead>
                    <tr>
                    <th>No</th>
                    <th>User Name</th>
                    <th>True Wallet</th>
                    <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
					                <?php for ($i = 0; $i < count($booklist); ++$i) { ?>
                <tr>
                    <td><?php echo ($page+$i+1); ?></td>
                    <td><?php echo $booklist[$i]->username; ?></td>
                    <td><?php echo $booklist[$i]->saldo; ?></td>
                    <td><?php echo $booklist[$i]->online; ?></td>
                </tr>
                <?php } ?>
                    </tbody>
                  </table>
				          </div>
    </div>
    
    <div class="row">
        	<div class="col-xs-12">
            <div class="box-header with-border">
            <center><?php echo $pagination; ?><center>
 </div>
 </div>
 </div> 			
    	</div>