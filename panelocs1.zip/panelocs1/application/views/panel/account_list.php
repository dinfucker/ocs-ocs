<body class="hold-transition skin-blue sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper"><!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1> Inbox <small>บัญชีที่เช่าทั้งหมด</small> </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo base_url('index')?>"><i class="fa fa-home"></i> Home</a></li>
      <li class="active">Inbox</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
  <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <div class="box-body">
            <div class="modal fade" id="delete">
              <div class="modal-dialog modal-md">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><i class="fa fa-trash"></i> Delete Confirmation</h4>
                  </div>
                  <div class="modal-body">
                    <h4>คุณแน่ใจหรือไม่ว่าต้องการลบรายการที่เลือก ?</h4>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> ยกเลิก</button>
                    <button type="submit" name="remove" class="btn-delete btn btn-danger"><i class="fa fa-trash"></i> ตกลง</button>
                  </div>
                </div>
              </div>
            </div>
            <div class="box-body no-padding ">
              <div class="mailbox-controls">
                <!-- Check all button -->
                <div class="btn-group">
                  <button type="button" data-target="#search_modal" data-toggle="modal" class="button button-flat-default button-tiny btn-sm"><i class="fa fa-search"></i> Search</button>
                  <button type="button" class="button button-flat-default button-tiny btn-sm" onclick='location.reload(true); return false;'><i class="fa fa-refresh"></i> Reload</button>
                </div>
                <!-- /.pull-right -->
              </div>
              <div class="table-responsive mailbox-messages">
                <table class="table table-hover table-striped">
                  <thead>
                    <tr>
                      <th>Del</th>
                      <th>User</th>
                      <th>Pass</th>
                      <th>Hostname</th>
                      <th>Expire</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if(!empty($account)):?>
                    <?php $jumlah=0; $counter=0; ?>
                    <?php foreach ($account as $row): ?>
                    <?php $counter++; ?>
                    <tr>
					<form action="<?php echo base_url('seller/delet_account/'. $row['id'])?>" method="post" accept-charset="utf-8">
                      <td><a href="<?php echo base_url('seller/delet_account/'. $row['id'])?>" class="btn btn-danger button-tiny"><span class="fa fa-trash-o fa-sm"></span></a> </td>
                      <td><?= $row['username'] ?>
                      </td>
                      <td>xxxxxx
                      </td>
                      <td class="mailbox-subject"><strong>
                        <?= $row['hostname']?>
                      </strong></td>
                      <td class="mailbox-date"><?php  $today=date('Y-m-d'); $expire=date('Y-m-d', strtotime($row['created_at']. '+30 days')); if ($today>=$expire){ echo $expire; } else{ echo $expire; } ?></td>
                    </tr>
                    <?php $jumlah = $jumlah + $row['price']; ?>
                    <?php endforeach; ?>
                    <?php else: ?>
                    <tr>
                      <td class="text-muted text-center" colspan="6"> คุณยังไม่ได้เช่าแพตเกจใด ๆ</td>
                    </tr>
                    <?php endif; ?>
                  </tbody>
                </table>
                <!-- /.table -->
              </div>
              <!-- /.mail-box-messages -->
            </div>
            <!-- /.box-body -->
          </form>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
  </div>
</div>
