   
  
  <div class="content-wrapper" style="min-height: 649px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1><b>
       วิธีใช้งานสำหรับระบบ Android
      </b></h1>
    <ol class="breadcrumb">
        <li><a href="/main"><i class="fa fa-home"></i>Home</a></li>
        <li class="active">วิธีใช้งาน OpenVPN</li>
    </ol>
    </section>
     <!-- Main content -->
    <section class="content">
                <br>
		<center>
    <h3>วิธีใช้สำหรับระบบ Android</h3>
	</center>
<div class="row">     
 <div class="col-sm-12">
      <div class="box box-solid box-primary">
        <div class="box-header text-center">
 		    <i class="fa fa-cog fa-spin"></i> <label style="width: 250px;">เพียง 7 ขั้นตอนง่ายๆ ดังนี้</label>
    			<div class="box-tools pull-right">
        	    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
			    </div>
      	  </div>
      
        <div class="box-body">
                    <center>
                      <div class="container single-tutorial-content">
						<p>1. ดาวน์โหลดแอพ OpenVPN Connect <a href="https://play.google.com/store/apps/details?id=net.openvpn.openvpn">++กดที่นี่++</a></p>
  
						<img class="alignnone size-full wp-image-18186" src="<?php echo  base_url('asset/img/openvpn/1.jpg') ?>" alt="6" width="300" height="500"><p></p>
					
						<p>2. เปิดแอพและเลือกเมนู<strong>OpenVPN profile</strong>.</p>

						<img class="alignnone size-full wp-image-18189" src="<?php echo  base_url('asset/img/openvpn/2.jpg') ?>" alt="10" width="300" height="500"><p></p>

						<p>3.เลือกไฟล์ <strong> vpn ที่คุณ Download มา</strong> </p>

						<img class="alignnone size-full wp-image-18190" src="<?php echo  base_url('asset/img/openvpn/3.jpg') ?>" alt="11" width="300" height="500"><p></p>

						<p>4. ใส่ชื่อและรหัสผ่านของคุณ ที่คุณสมัครมาของ เซิร์ฟเวอร์ นั้นๆ<strong> แล้วกด ADD.</strong></p>
						<img class="alignnone size-full wp-image-18190" src="<?php echo  base_url('asset/img/openvpn/4.jpg') ?>" alt="11" width="300" height="500"><p></p>
						
						<p>5. กด <strong>Connect</strong>.<br>

						<img class="alignnone size-full wp-image-18194" src="<?php echo  base_url('asset/img/openvpn/5.jpg') ?>" alt="17" width="300" height="500"></p>

						<p>6. กด <strong>CONTINUE.</strong> <br>

						<img class="alignnone size-full wp-image-18196" src="<?php echo  base_url('asset/img/openvpn/6.jpg') ?>" alt="19" width="300" height="500"></p>

						<p>7. เพียงเท่านี้ก้อสามารถใช้งานได้แล้วครับ หากจะยกเลิกการเชื่อมต่อ กดที่ <strong>Disconnect</strong>.</p>

						<img class="alignnone size-full wp-image-18196" src="<?php echo  base_url('asset/img/openvpn/7.jpg') ?>" alt="19" width="300" height="500"><p></p>
		</div><table class="table">                   
                       <tbody><tr>
                            
                        </tr>
                       
                    </tbody></table>
                  </div>
            
     	   </div>
          </div>
	   </div>                
 </section>  
</div>

  