<html lang="en" style="height: auto;"><head>
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<meta name="keywords" content="">
		<meta name="author" content="">
		<title>LIFESTYLE VPN</title>
		
<!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href="<?php echo  base_url('asset/font-awesome/css/font-awesome.min.css')?>" rel="stylesheet"/>
    <!-- Plugin CSS -->
    <link href="<?php echo  base_url('asset/css/animate.min.css" type="text/css')?>" rel="stylesheet"/>
    <!-- Custom CSS -->
    <link href="<?php echo  base_url('asset/css/creative.css" type="text/css')?>" rel="stylesheet"/>
  	
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
		<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
	
		
       
		<LINK REL="SHORTCUT ICON" HREF="<?php echo  base_url('asset/img/icon/i5.png') ?>"
	
		
	</head>
	
	
	<body class="skin-black-light fixed sidebar-mini" id="page-top" style="height: auto;">

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="LIFESTYLE VPN">
<meta name="author" content="LIFESTYLE VPN">
<link rel="stylesheet" href="/signup/css/bootstrap.min.css" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="/signup/font-awesome/css/font-awesome.min.css" type="text/css">

<link rel="stylesheet" href="/signup/css/animate.min.css" type="text/css">

<link rel="stylesheet" href="/signup/css/creative.css" type="text/css">




<section id="services">
<div class="container">
<div class="row">
<div class="col-lg-12 text-center">
<br>
 <img class="img-circle" src="<?php echo  base_url('asset/img/icon/i3.png') ?>" width="100" height="97">

					          <h2 style='color:#000033'><b>LIFESTYLE VPN</b></h2>
							  	   
                    <span style="font-size: 21px;" class="badge bg-dark"></b>
         <b>ยินดีต้อนรับ</b>

</div>
</div>
</div><br>

<div class="container">
<div class="row">
<div class="col-md-4 col-md-offset-4">
<div class="col-md-12">



<form action="/login" method="post">
<div class="login">
<?php if (validation_errors()) : ?>
                    <div class="alert alert-danger"><?php echo  validation_errors() ?></div>
                <?php endif; ?>
                <?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  $error ?></div>
					</div>
				<?php endif; ?>
		
   			 <?php echo  form_open() ?>
<form action="/login" method="post" class="ng-pristine ng-valid">
<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
<input required="required" id="username" type="text" class="form-control" onblur="checkText();" name="username" value="" placeholder="Username" minlength="3">
</div>
<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="fa fa-key"></i></span>
<input required="required" id="password" type="password" class="form-control" name="password" placeholder="Password">
</div>


               
                                            <button type="submit" name="submit" class="btn btn-success pull-left">
                                            <i class="fa fa-lock">
											                      </i> เข้าสู่ระบบ
                                            </button>
                                            <a href="/register" class="btn btn-danger pull-right">
                                                <i class="fa fa-unlock">
												                       </i> สมัครบัญชี
                                             </a>
                                     </div>
                                         </div>
                                       </div>
          </div> <br> 
		  <center><b>จำนวนคนเข้าชมเว็บ</b>
		  <script type='text/javascript' src='https://www.siamecohost.com/member/gcounter/graphcount.php?page=lifestylevpn.ga&style=02&maxdigits=5'></script></center><br> 

 
    <CENTER>
                           <b> <strong>เว็บเปิดมาแล้ว :</strong> <script> 
var montharray=new Array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")
 
function countup(yr,m,d){
var today=new Date()
var todayy=today.getYear()
if (todayy < 1000)
todayy+=1900
var todaym=today.getMonth()
var todayd=today.getDate()
var todaystring=montharray[todaym]+" "+todayd+", "+todayy
var paststring=montharray[m-1]+" "+d+", "+yr
var difference=(Math.round((Date.parse(todaystring)-Date.parse(paststring))/(24*60*60*1000))*1)
difference+=" "
document.write(" "+difference+" ")
}
//พิมพ์วันเรียงตามดังนี้  ( ปี ค.ศ./เดือน/วัน)
countup(2017,07,07)
                  </script></span> วัน</b></div>
				
</CENTER>

</body></html>