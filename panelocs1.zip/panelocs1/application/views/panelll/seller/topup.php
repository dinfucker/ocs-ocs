<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
<section class="content-header">
<h1>
ระบบเติมเงิน บัตรทรูมันนี่
</h1>
<ol class="breadcrumb">
<li><a href="/main"><i class="fa fa-home"></i> หน้าหลัก</a></li>
<li class="active">TRUE MONEY</li>
</ol>
</section><br>

<div class="row">
			<?php if (isset($message)) {echo $message; }?>   
		</div>
		


<section class="content">
<div class="row">
<div class="col-md-12">
<div class="box box-widget widget-user">
<div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/6.png') ?>') center center;">


<span class="info-box-number">ยอดเงินคงเหลือ » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-blue"><?= $user -> saldo ?> บาท</span>
<span class="info-box-number">ชื่อบัญชี » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-blue"><?php echo  $user->username ?></span></span>


</b></div><b>
<div class="widget-user-image">
<img class="img-circle" src="https://upload.wikimedia.org/wikipedia/commons/5/50/Bitcoin.png" alt="User Avatar">
</div>
<div class="box-footer no-padding">
<div class="description-block"><br><br>
<span class="description-text"><span style="font-size: 16px;" class="badge bg-red">รายละเอียด</span></span>
</div>
<ul class="nav nav-stacked text-center">
<li><a href="#"><b> <span style="font-size: 16px;" class="badge bg-black"> เติมด้วยบัตรเงินสดทรูมันนี่ </span></b></a></li>
<li><a href="#"> <span style="font-size: 16px;" class="badge bg-black"> ระบบจะไม่มีการหักค่าธรรมเนียม </span></a></li>
</ul>
</div>
<center><span class="description-text"><span style="font-size: 16px;" class="badge bg-red">กรอกหมายเลขบัตรเงินสด</span></span></center>
<div class="box-footer">
<input name="tmn_password" type="number" id="tmn_password" maxlength="14" class="form-control" placeholder="ใส่รหัสบัตรเงินสดทรูมันนี่ 14 หลัก">
				 <input name="ref1" type="hidden" value="<?php echo  $user->id ?>" id="ref1">
				 <input name="ref2" type="hidden" value="<?php echo  $user->username ?>" id="ref2">
				 <input name="ref2" type="hidden" value="<?php echo  $user->email ?>" id="ref2">    
					</div>	
<center><button type="button" class="btn btn-success btn-md" onclick="submit_tmnc()"><i class="fa fa-money"></i> ยืนยันเติมเงิน</button>
<a href="<?php echo  base_url('main/'.$_SESSION['username'].' ')?>" class="btn btn-warning"><i class="fa fa-home"></i> ย้อนกลับ</a>
<br><br><span style="font-size: 14px;" class="badge bg-black">เติมเท่าไรได้เท่านั้น</span><br><br>
</center>
</b></div><b>
</b></div><b>
</b></div><b>
</b></section></div><b>
</b></div><b>
<!-- ???????? UID ???????????????? UID Tmtopup ??????????  -->
<script type="text/javascript" src='https://www.tmtopup.com/topup/3rdTopup.php?uid=214380'></script>

  <!-- /.content-wrapper -->



