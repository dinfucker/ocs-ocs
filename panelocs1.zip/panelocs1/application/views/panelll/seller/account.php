<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       ประวัติการเช่า
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i>หน้าหลัก</a></li>
        <li class="active">ประวัติการเช่า</li>
    </ol>
    </section><br>

			    <!-- Main content -->
  		  <!---section class="content">
				<br><div class="row">
                    <div class="col-md-2 text-center">
                        <label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-success">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Repost</label>                        
                    </div>
                </div----->
				
    <div class="row">
            <div class="col-lg-12 hidden-print">                    
                <?php echo  $user['message']?>
            </div>
        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-user fa-fw"></i> บัญชี VPN ของคุณ
                </div>
                <div class="panel-body">
                <table class="table table-hover">
                    <tbody>
                        <tr>
                            <td>ชื่อ</td><td>:</td><td><?php echo  $user['username']?></td>
                        </tr>
                        <tr>
                            <td>รหัส</td><td>:</td><td><?php echo  $user['password']?></td>
                        </tr>
                        <tr>
                            <td>โฮส</td><td>:</td><td><?php echo  $user['hostname']?></td>
                        </tr>
                        <tr>
                            <td>เซิร์ฟเวอร์</td><td>:</td><td><?php echo  $user['location']?></td>
                        </tr>
                        <tr>
                            <td>Openssh</td><td>:</td><td><?php echo  $user['openssh']?></td>
                        </tr>
                         <tr>
                            <td>Dropbear</td><td>:</td><td><?php echo  $user['dropbear']?></td>
                        </tr>
                         <tr>
                            <td>ราคา</td><td>:</td><td><?php echo  $user['price']?></td>
                        </tr>
                        <tr>
                            <td>วันหมดอายุ</td><td>:</td><td><?php echo  date("Y-m-d H:i:s",strtotime("+".$user['expired']."days", time( )))?></td>
                        </tr>
                    </tbody>
                </table>
                <p class="text-muted">
					คำเตือน:<br>
ควรบันทึกภาพประวัติการเช่าไว้ กันเวลาลืมชื่อ? จำรหัสไม่ได้? หรือไฟล์มีปัญหาต่อไม่ติด ท่านสามารถบันทึกภาพเป็นหลักฐานไปแจ้งกับแอดมินได้ครับ....

                </p>
					<div class="hidden-print">
					<a href="#" class="btn btn-primary" onclick="print_report()">Print</a>
					<a href="<?php echo  base_url('panel/reseller/'.$_SESSION['username'].'/server') ?>" class="btn btn-default">Kembali</a>
					</div>
				</div>
            </div>
        </div>
    </div>
</div>