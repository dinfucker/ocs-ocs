<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
     สร้างบัญชี VPN
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i>หน้าหลัก</a></li>
		<il class="active">/สร้างบัญชี</li>
    </ol>
    </section>
    		<section class="content">
   			 <div class="row">
                    <div class="col-md-12 text-center">
                        <!---label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-primary">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No BUG</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Error</label>
                        <label class="label label-danger">No Repost</label--->
                    </div>
                </div>

<center><button style="font-size: 16px;" class="badge bg-maroon btn-outline-danger my-2 my-lg-5" type="button"><span class="fa fa-money"></span> ยอดเงินคงเหลือ : <?php echo $user->saldo ?>บาท</button></center><br>

       <!---div class="btn btn-warning"> ยอดเงินคงเหลือ : <a><?php echo  $user->saldo ?></a></div> 
    <br><br--->
  
     <div class="row">
         <div class="col-lg-12">
             <div class="box box-widget widget-user">               
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/300.jpg') ?>') center center;">
              <h3 class="widget-user-username"><?php echo  $server->ServerName ?></h3>
              <h5 class="widget-user-desc"><?php echo  $server->Expired ?> วัน <?php echo  $server->Price?> บาท <B></h5>
              
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="<?php echo  base_url('asset/img/user1.png') ?>" alt="User Avatar">
            </div>
			 <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">รายละเอียดเซิร์ฟเวอร์</span></span>
         </div>
         
              <ul class="nav nav-stacked">
                <li><a href="#"><B> เซิร์ฟเวอร์ </B><span class="pull-right"><B>IP HOST</B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-aqua"><?php echo  $server->Location?></span> <span style="font-size: 16px;" class="pull-right badge bg-purple">แสดงเมื่อเช่าแล้ว</span></a></li>
                
                <li><a href="#"><B> PORT</B> <span class="pull-right"><B>จำกัดการเชื่อมต่อ</B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-maroon"><?php echo  $server->OpenSSH?>, <?php echo  $server->Dropbear?></span><span style="font-size: 16px;" class="pull-right badge bg-navy"> VPN <?php echo  $server->limitvpn?> เครื่อง <!--?php echo  $row['limitssh']?--></span></a></li>
                
                <li><a href="#"> <B>วันใช้งาน </B><span class="pull-right"> <B>จำกัด</B> </span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-purple"><?php echo  $server->Expired?> วัน </span><span style="font-size: 16px;" class="pull-right badge bg-blue"><?php echo  $server->MaxUser?> คน/วัน </span></a></li>
                
                <li><a href="#"> <B>ราคา</B> <span class="pull-right"><B> สถานะเซิร์ฟเวอร์</B> </span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-green"><?php echo  $server->Price?> บาท </span><span style="font-size: 16px;" class="pull-right badge bg-orange"> <?php if ($server->Status) { echo 'ออนไลน์';} else {echo "เซิร์ฟเวอร์เต็ม";}?></span></a></li>
                
              </ul>
            </div>
			
                
            <div class="col-lg-12">
                <?php if (isset($message)) {echo $message; }?>
            </div>
                    
                    <div class="box-body">
					<?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  $error ?></div>
					</div>
					<?php endif;?>
                    <?php echo  form_open() ?>
						<div class="form-group">
							<label for="username">Username</label>
							<input type="text" name="username" class="form-control" id="username" placeholder="ตัวอักษรอย่างน้อย 5 ตัวห้ามใช้ภาษาไทยหรืออักษรพิเศษ"/>
						</div>
						<div class="form-group">
							<label for="password">Password </label>
							<input type="text" name="password" id="password" class="form-control" placeholder="ตัวอักษรหรือตัวเลขอย่างน้อย 5 ตัว"/>
						</div> 
                    
                    </div>
                    <div class="box-footer text-center">
                    <input type="submit" class="btn btn-primary" value="ยืนยัน"/>
                    </form>
                    </div>
                </div>
            </div>
        

      </section>
</div>