<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div class="content-wrapper">
    <section class="content-header">
      <h1>
        โปรไฟล์
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> หน้าหลัก</a></li>
        <li class="active">โปรไฟล์</li>
      </ol>
    </section>

 <section class="content">
 	<div class="row">
		<div class="section" id="carousel">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2">
						<div class="card card-raised card-carousel">
							<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
								<div class="carousel slide" data-ride="carousel">

									<!-- Indicators -->
									<ol class="carousel-indicators">
										<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
										<li data-target="#carousel-example-generic" data-slide-to="1"></li>
										<li data-target="#carousel-example-generic" data-slide-to="2"></li>
										<li data-target="#carousel-example-generic" data-slide-to="3"></li>
										
									</ol>

									<!-- Wrapper for slides -->
									<div class="carousel-inner">
										<div class="item active">
											<img src="<?php echo  base_url('asset/img/fb.jpg') ?>" alt="Awesome Image">
											<div class="carousel-caption">
												<h4><i class="material-icons">    </i> </h4>
											</div>
										</div>
										<div class="item">
											<img src="<?php echo  base_url('asset/img/x1.png') ?>" alt="Awesome Image">
											<div class="carousel-caption">
												<h4><span class="description-text"><span style="font-size: 16px;"  class="badge bg-green"><i class="material-icons">ภาพใช้งานบน PC</i></span> </h4>
											</div>
										</div>
										<div class="item">
											<img src="<?php echo  base_url('asset/img/x2.png') ?>" alt="Awesome Image">
											<div class="carousel-caption">
												<h4><span class="description-text"><span style="font-size: 16px;"  class="badge bg-green"><i class="material-icons">ภาพใช้งานบน PC</i></span> </h4>
											</div>
										</div>
										<div class="item">
											<img src="<?php echo  base_url('asset/img/x3.png') ?>" alt="Awesome Image">
											<div class="carousel-caption">
												<h4><span class="description-text"><span style="font-size: 16px;"  class="badge bg-green"><i class="material-icons">ภาพใช้งานบน PC</i></span> </h4>
											</div>
										</div>
										
										</div>
									</div>

									<!-- Controls -->
									<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
										<i class="material-icons">keyboard_arrow_left</i>
									</a>
									<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
										<i class="material-icons">keyboard_arrow_right</i>
									</a>
								</div>
							</div>
						</div>
						<!-- End Carousel Card -->

					</div>
				</div>
			</div>
		</div>

		<div class="row">
  <section class="content">
       <div class="col-sm-13">    
        <div class="box box-widget widget-user">
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/j3.jpg') ?>') center center;">
              <!--h3 class="widget-user-username"><B><?php echo  $_SESSION['username'] ?> <B></h3>
              <h4 class="widget-user-desc"><B><?php echo  $user -> saldo ?>  บาท <B></h4-->
              
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="<?php echo  base_url('asset/img/user1.jpg') ?>" alt="User Avatar">
            </div>





                  



       <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">รายละเอียดบัญชี</span></span>
         </div>
         
              <ul class="nav nav-stacked">
              	<li><a href="#"><span style="font-size: 16px;" class="badge bg-aqua">ชื่อบัญชีผู้ใช้</span> <span style="font-size: 16px;" class="pull-right badge bg-purple">เงินในบัญชี</span></a></li>  
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-maroon"><?php echo  $_SESSION['username'] ?></span> <span style="font-size: 16px;" class="pull-right badge bg-yellow"><?php echo  $user -> saldo ?> บาท</span></a></li>  
                
                                 </ul>
                             </div> 
                    
                      </div>
                   </div>
        
             </div>
          </div>     
	   </div>
    </section>
  </div>  

