<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
 <div class="content-wrapper">
    <section class="content-header">
      <h1>
        ตั้งค่าโปรไฟล์
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li class="active">ตั้งค่าโปรไฟล์</li>
      </ol>
    </section>
   				
   <section class="content">
   <p></p>
                
        <div class="box box-danger">
            <div class="box-header with-border">
               <i class="fa fa-cog fa-spin"></i><h3 class="box-title">เปลี่ยนรหัสผ่านบัญชีใหม่</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
        <div class="row">
        <div class="col-md-6">
			<?php if (isset($message)) {echo $message; }?>
			<?php if (isset($success)) {echo $success; }?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-gear fa-fw"></i> &#3648;&#3611;&#3621;&#3637;&#3656;&#3618;&#3609;&#3619;&#3627;&#3633;&#3626;&#3612;&#3656;&#3634;&#3609;
                </div>
                <div class="panel-body">
                    <form role="form" action="<?= base_url('main/'.$_SESSION['username'].'/setting')?>" method="POST">
						<input type="hidden" name="username" value="<?= $_SESSION['username'] ?>">
                        <div class="form-group">
                            <label>&#3619;&#3627;&#3633;&#3626;&#3612;&#3656;&#3634;&#3609;&#3648;&#3604;&#3636;&#3617;</label>
                            <input class="form-control" placeholder="Old Password" name="oldpass" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>รหัสผ่านใหม่</label>
                            <input class="form-control" placeholder="ใส่-รหัสผ่านใหม่" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>รหัสผ่านใหม่อีกครั้ง</label>
                            <input class="form-control" placeholder="ใส่-รหัสผ่านใหม่อีกครั้ง" name="passconf" type="password" required>
                        </div>
                        <button type="button" class="btn btn-danger form-control" data-toggle="modal" data-target="#modal-danger">เปลี่ยนรหัสผ่าน</button>
						<div class="modal modal-danger fade" id="modal-danger">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span></button>
<h4 class="modal-title">แจ้งเตือนการเปลี่ยนรหัสผ่าน</h4>
</div>
<div class="modal-body">
<p>กรุณาเช็ครหัสก่อนที่จะกดยืนยัน</p>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-outline pull-left" data-dismiss="modal">ยกเลิก</button>
<button type="submit" class="btn btn-outline">ยืนยัน</button>
</div>
</div>

</div>

</div>

</form> 
<div class="box-footer">
</div>
</div>

                    </form>
                </div>
            </div>
        </div>
      </div>
      </div>   

                          <div class="box-footer">
                       </div>
                  </div>         
	        	</div>
        </div>
    </section>
  </div>