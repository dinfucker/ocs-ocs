<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div class="content-wrapper">
   <section class="content-header">
   	    <h1>
ประกาศข่าวสาร
      </h1>
      <ol class="breadcrumb">
        <li><a href="main"><i class="fa fa-home"></i> หน้าหลัก</a></li>
        <li class="active">กิจกรรมและประกาศ</li>
      </ol>
  </section>
  <section class="content">
<div class="row">
<div class="col-md-12">
<div class="nav-tabs-custom">
<ul class="nav nav-tabs pull-left">
<li class="animated infinite tada active"><a href="#tab_1-1" data-toggle="tab">ประกาศ!!</a></li>
<li class="animated infinite rubberBand"><a href="#tab_2-2" data-toggle="tab">รายละเอียดการใช้</a></li>
<li><span><iframe src="https://free.timeanddate.com/clock/i5yocovd/n28/tlth39/fn6/fs16/ftb/th1" frameborder="0" width="70" height="35"></iframe></span></li>
<!--li class="pull-left header"><i class="fa fa-th"></i> กิจกรรมและประกาศต่างๆ</li--></ul>

<div class="tab-content"> 
<div class="tab-pane active" id="tab_1-1"><br><br>
<!--h4><font color="red"><b>ตั้งแต่วันที่ 02/06/61 จะปรับราคาเซิฟไทยเหลือ 40 บาท. ต่อเดือนครับ ลดราคากันยาวๆ  อย่าลืมจัดกันน่ะครับ</b></h4> </font-->
<h4><b>📢 ประกาศๆดีแทค ใครอยากใช้สามารถติดต่อทดลองได้ 😑😑😑 Updatepdate File ล่าสุด ณ วันที่ 23/07/2561 07.00 น. </b></h4>
<p>
									 <p>
                 </p><h4><b> เบอร์สมัครโปร DTAC VIBER	 </b></h4>	<p></p>							
                  <center>
  
<p><u></u></p><h4> DTAC VIBER 1 วัน 5 บาท </h4>

<strong>เบอร์สมัคร</strong> : <span class="style3f">*104*600</span># <a href="tel:*104*600%23"><button class="btn btn-info waves-effect waves-light" type="button">สมัคร</button></a><p></p>

<p><u></u></p><h4> DTAC VIBER 7 วัน  19 บาท</h4>

<strong>เบอร์สมัคร</strong> : <span class="style3f">*104*601</span># <a href="tel:*104*601%23"><button class="btn btn-info waves-effect waves-light" type="button">สมัคร</button></a><p></p>

<p><u></u></p><h4>DTAC VIBER 1 เดือน 49 บาท </h4>

<strong>เบอร์สมัคร</strong> : <span class="style3f">*104*602</span># <a href="tel:*104*602%23"><button class="btn btn-info waves-effect waves-light" type="button">สมัคร</button></a><p></p>
              
</center>
 
<p><b>เซิฟแนะนำ เน้นเกมส์  Rov Free Fire PUBG เซิฟ TH-VIP รับรองลื่นๆ รับประกัน</b></p>
<p><b>เซิฟแนะนำ ใช้งานทั่วไป  Youtube Facebook Line ไม่เล่นเกม เซิฟ SG จะประหยัดกว่า</b></p>
<!----------------------แอพ openVPN-------------------------->
<p><b>หากใครที่อัพเดทแอพ OpenVPN Connect &nbsp;
</b><img class="img-circle" src="<?php echo  base_url('asset/img/icon/i3.png') ?>"width="31" height="31"><br>
แล้วใช้ไม่ได้เชื่อมต่อแล้ว error..<br>
ให้โหลดแอพกลับมาเวอร์ชั่นเดิมน่ะครับ..<br>
<b>#หมายเหตุ:</b>มีปัญหาด้านการใช้งานหรืออื่นๆ ติดต่อแอดมิน(เจมส์)
<a href="https://m.me/jamejaturaporn.suriya.5"> กดตรงนี้ครับ. &nbsp; 
<img class="img-circle" src="<?php echo  base_url('asset/img/icon/i2.gif') ?>"width="31" height="31"></a></p></div>



<div class="tab-pane" id="tab_2-2">
<h3><b></b></h3><br><br><br><br>

<!--------------------รายละเอียดการใช้งาน-------------------------->
<center><span style="font-size: 17px;" class="badge bg-maroon">รายละเอียดการใช้งาน</span><br>
				
				<p><b>บริการเช่าอินเตอเน็ตเชื่อมต่อผ่านระบบ VPN <br>รองรับซิมทรูและดีแทคโปรไลน์</p></b></center>
				
				<span style="font-size: 15px;" class="badge bg-purple">ข้อตกลง </span><br>
				<p>การใช้งานความเร็วและความแรงของอินเตอร์เน็ตแต่ละพื้นที่ก็ต่างกันไป ถ้าหากเน็ตของลูกค้าช้าหรือมีปันหาอื่นๆ 
				ก่อนที่จะมาแจ้งปัญหา กรุณาให้ลูกค้าตรวจสอบปัญหาให้แน่ชัดก่อนว่าเกิดจากอะไร ถ้าหากปันหาที่เป็นอยู่เกียวกับพืันที่หรือเครื่องของลูกค้าเองและอื่นๆ
				ที่ไม่เกียวกับเซิฟร์เวอร์ ทางเราก็ไม่สารถแก้ปันหานั้นได้ ทางเราแก้ได้เฉพาะปัญหาที่เกียวกับเซิฟร์เวอร์ของเราเท่านั้น จะเช่าหรือไม่นั้น ทางเราไม่บังคับ
				เป็นการตัดสิ้นใจของลูกค้าเอง เพราะฉะนั้นถ้าเช่าไปแล้ว จะไม่มีการคืนเงินไม่ว่ากรณีใดๆก็ตาม </p>
				
</tr></tbody>
</table>
</div>
</div>
</div>
</div>
</div>

<div class="row">
<div class="col-md-6 col-md-6 col-xs-12">
<div class="info-box bg-info"style="background: url('<?php echo  base_url('/asset/img/Background/Background1.png') ?>') center center;">
<span class="info-box-icon"><i class="fa fa-ge"></i></span>
<div class="info-box-content">
<span class="info-box-number">ยอดเงินคงเหลือ » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-blue"><?= $user -> saldo ?> บาท</span>
<span class="info-box-number">ชื่อบัญชี » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-blue"><?php echo  $user->username ?></span></span>
<div class="progress">
<div class="progress-bar" style="width: 0%"></div>
</div>
<span class="progress-description">
<a href="<?= base_url('main/'.$_SESSION['username'].'/topups') ?>">เติมเงิน <i class="fa fa-arrow-circle-right"></i></a>
</span>
</div>
</div>
</div>


<div class="col-md-6 col-md-6 col-xs-12">
<div class="info-box bg-info"style="background: url('<?php echo  base_url('/asset/img/Background/Background2.png') ?>') center center;">
<span class="info-box-icon"><i class="fa fa-drupal"></i></span>
<div class="info-box-content">
<span class="info-box-number">ID ACCOUNT » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-blue"><?php echo  $user->id ?></span></span>
<span class="info-box-number">Email » <span style="font-size: 10px;" class="info-box-number pull-right badge bg-blue"><?php echo  $user->email ?></span></span>
<div class="progress">
<div class="progress-bar" style="width: 0%"></div>
</div>
<span class="progress-description">
<a href="<?= base_url('main/'.$_SESSION['username'].'/profile') ?>">วิธีใช้สำหรับระบบ Android <i class="fa fa-arrow-circle-right"></i></a>
</span>
</div>
</div>
</div>


            
                           <center>
						  <div class="fb-page" data-href="https://www.facebook.com/lifestylevpn/" data-tabs="timeline" data-width="500" data-height="350" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/lifestylevpn/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/lifestylevpn/">Lifestyle-vpn</a></blockquote></div>
						   </center>
						</div>
                        </div>
                    </div> 

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/th_TH/sdk.js#xfbml=1&version=v3.0';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
</div>
  </div>

  