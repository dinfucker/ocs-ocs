<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       เพิ่มเซิร์ฟเวอร VPN
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i> หน้าหลัก </a></li>
        <li class="active"> เพิ่มเซิร์ฟเวอร </li>
    </ol>
    </section><br>
    		
      
    <div class="row">
            
				<?php if (isset($message)) { echo $message; }?>               
            </div>
        <div class="col-md-12">
            <div class="panel panel-danger">
                <div class="panel-heading">
                    <i class="fa fa-gear fa-fw"></i>  รายละเอียดเซิร์ฟเวอร์
                </div>
                <div class="panel-body">
                    <form action="<?php echo  base_url('main/administrator/'.$_SESSION['username'].'/'.'addserver') ?>" method="POST">
                        <div class="form-group">
                            <label> เซิร์ฟเวอร์ </label>
                            <input class="form-control" placeholder="ชื่อเซิร์ฟเวอร์" name="ServerName" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>ประเทศ</label>
                            <select class="form-control" name="Location">
								<?php foreach($this->user_model->get_country() as $row):?>
								<option value="<?php echo  $row['Country'] ?>"><?php echo  $row['Country'] ?></option>
								<?php endforeach;?>
							</select>
                        </div>
                        <div class="form-group">
                            <label>IP / Host</label>
                            <input class="form-control" placeholder="ตัวอย่าง 128.199.249.226" name="HostName" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>Port SSH</label>
                            <input class="form-control" placeholder="22" name="OpenSSH" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>Port Dropbear</label>
                            <input class="form-control" placeholder="443" name="Dropbear" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>จัดกัดการเชื่อมต่อ SSH</label>
                            <input class="form-control" placeholder="2" name="limitssh" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>จัดกัดการเชื่อมต่อ VPN</label>
                            <input class="form-control" placeholder="1" name="limitvpn" type="text" required>
                        </div>
                        <div class="form-group">
                            <label> ชื่อไฟล์ SSH</label>
                            <input class="form-control" placeholder=" ตัวอย่าง TH1.LIFESTYLE-VPN.ehi" name="configssh" type="text" required>
                        </div>
                        <div class="form-group">
                            <label> ชื่อไฟล์ VPN</label>
                            <input class="form-control" placeholder="ตัวอย่าง  TH1.LIFESTYLE-VPN.ovpn" name="configvpn" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>จำนวนวันใช้งาน</label>
                            <input class="form-control" placeholder="7" name="Expired" type="text" required>
                        </div>
                        <div class="form-group">
                            <label> ราคาเซิร์ฟเวอร์ </label>
                            <div class="input-group">
                                <span class="input-group-addon">Wallet </span>
                                <input class="form-control" placeholder="10" name="Price" type="number" step="1" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>รหัส VPS</label>
                            <input class="form-control" placeholder="r0oT_p4s5wo0rD" name="RootPasswd" type="text">
                        </div>
                        <input type="submit" class="btn btn-primary" value="ยืนยัน">
                        <a href="<?php echo  base_url('main/administrator/'.$_SESSION['username'].'/'.'server') ?>" class="btn btn-danger">ยกเลิก</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

      </section>
</div>