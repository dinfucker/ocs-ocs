<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       ????????????????
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i> ????????</a></li>
        <li class="active">????????????????</li>
    </ol>
    </section>
    		<section class="content">
   			 <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-primary">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No BUG</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Error</label>
                        <label class="label label-danger">No Repost</label>
                    </div>
                </div>
			<br>
       
    <div class="row">
    	<div class="col-lg-6">
          <div class="panel panel-warning">
                <div class="panel-heading">
                    <h3 class="panel-title">??????????</h3>
                </div>
                <?php if (isset($success)) {echo $success; }?>
			  <?php if (validation_errors()) : ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
					<?php echo  validation_errors() ?>
				</div>
			</div>
		<?php endif; ?>
		<?php if (isset($error)) : ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
					<?php echo  $error ?>
				</div>
			</div>
		<?php endif; ?>
		<div class="col-md-12">
			
			<?php echo  form_open() ?>
				<div class="form-group">
					<label for="username">?????????</label>
					<input type="text" class="form-control" id="username" name="username" placeholder="????????? 4 ???">
					
				</div>
					<label for="email">Email</label>
					<input type="email" class="form-control" id="email" name="email" placeholder="Email">
					
					<label for="password">????????</label>
					<input type="password" class="form-control" id="password" name="password" placeholder="????????? 6 ???">
					
					<label for="password_confirm">??????????????</label>
					<input type="password" class="form-control" id="password_confirm" name="password_confirm" placeholder="??????????">
				
				<div class="form-group">
					<button class="btn btn-md btn-block btn-success" type="submit"><i class="fa fa-lock"></i> ??????</button>
				</div>
		           </div>
					  </form>
						</div>
						   </div>
					 </div>
    			</div>
    
      </section>
</div>