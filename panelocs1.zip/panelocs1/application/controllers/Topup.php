<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Topup extends CI_Controller {

	public function __construct() {
		parent::__construct();
			$this->load->model('user_model');
			$this->load->helper('url_helper');
			$this->load->library('sshcepat');
			$this->load->library(array('session'));
	}
		private function _set_view($file, $init) {
			$this->load->view('panel/base/page_header');
			$this->load->view($file, $init);
			$this->load->view('panel/base/footer');
	} 
	public function index()
	{
		$this->_set_view('get', $data);
	}
}