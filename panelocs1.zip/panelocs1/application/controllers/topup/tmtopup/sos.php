<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"><head>
    <title>OCSPANEL.INFO — ปรับปรุง</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="description" content="This is a default index page for a new domain."/>
    <style type="text/css">
        body {font-size:10px; color:#777777; text-align:center;}
        h1 {font-size:64px; color:#555555; margin: 70px 0 50px 0;}
        p {width:320px; text-align:center; margin-left:auto;margin-right:auto; margin-top: 30px }
        div {width:320px; text-align:center; margin-left:auto;margin-right:auto;}
        a:link {color: #34536A;}
        a:visited {color: #34536A;}
        a:active {color: #34536A;}
        a:hover {color: #34536A;}
    </style>
</head>
  <style> 
@font-face {
    font-family: myFirstFont;
    src: url(/asset/css/woff.ttf);
}

body {
    font-family: myFirstFont;
}
</style>
<body>
	<img src="http://139.59.120.41:85/os.gif" width="30%" height="30%">
    <h1>OCSPANEL.INFO</h1>
    <h1>ปรับปรุงเป็นเวลา 60 นาที</h1>
    
    <h3>ติดต่อ Admin  ได้โดยตรง</h3>
                                         
                                      		<a href="https://m.me/ceolnw" target="_blank">
                                            <img src="https://aovpn.in.th/images/messenger.jpg" style="height: 200px">                                        </a><a href="https://m.me/ceolnw" target="_blank"></a>
</body>

</html>

