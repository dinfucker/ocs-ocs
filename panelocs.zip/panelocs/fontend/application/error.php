<?php
header("location: /");
;>