<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
    	<check if="{{ @vpnseven->id }}">
          <true>
          <h1>
          {{ @vpnseven->servername }}
          </h1>
          </true>
         <false>
         <h1>
          ADD SERVER
         </h1>
         </false>
        </check>
     
      <ol class="breadcrumb">
                 <check if="{{ @vpnseven->id }}">
                    <true>
        <li><a href="/dashboard"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li><a href="/admin/vpnseven">รายชื่อเซิร์ฟเวอร์</a></li>
        <li class="active">แก้ไข {{ @vpnseven->servername }}</li>
                    </true>
                    <false>
                             <li><a href="/dashboard"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li><a href="/admin/vpnseven">รายชื่อเซิร์ฟเวอร์</a></li>
        <li class="active">เพิ่มเซิร์ฟเวอร์</li>
                    </false>
                </check>     
     
      </ol>
    </section>

    <section class="content">			
 		<div class="row">
        <div class="col-md-6">	
	        <check if="{{ @message }}">     
				<div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-info"></i>{{ @message['type'] }}</h4>
                {{ @message['data'] }}
              </div>
            </check>
        
		 <div class="box box-primary">
            <div class="box-header with-border">
               <i class="fa fa-user fa-fw"></i><h3 class="box-title"> Server Settings</h3>
            </div>              

            <form role="form" action="{{ @URI }}" method="POST">
              <div class="box-body">
                        <div class="form-group">
                            <label>เซิร์ฟเวอร์</label>
                            <input class="form-control" placeholder="Singapore" name="country" type="text" value="{{ @vpnseven->country }}" required>
                        </div>
						<div class="form-group">
                            <label>ชื่อของ CLOUD VPS</label>
                            <input class="form-control" placeholder="Digital Ocean, Vultr" name="servername" type="text" value="{{ @vpnseven->servername }}" required>
                        </div>
                        <div class="form-group">
                            <label>Host</label>
                            <input class="form-control" placeholder="128.199.xxx.xx" name="host" type="text" value="{{ @vpnseven->host }}" required>
                        </div>
                        <div class="form-group">
                            <label>IP ADDRESS</label>
                            <input class="form-control" placeholder="LOWCLASS" name="ip" type="text" value="{{ @vpnseven->ip }}" required>
                        </div>
						<div class="form-group">
                            <label>SSH PORT</label>
                            <input class="form-control" placeholder="22,443" name="dropbear" type="text" value="{{ @vpnseven->dropbear }}" required>
                        </div>
						<div class="form-group">
                            <label>สมัครได้ต่อวัน</label>
                            <input class="form-control" placeholder="50" name="limitacc" type="text" value="{{ @vpnseven->limitacc }}" required>
                        </div>
                        <div class="form-group">
                            <label>จำกัด VPN</label>
                            <input class="form-control" placeholder="1" name="limitvpn" type="text" value="{{ @vpnseven->limitvpn }}" required>
                        </div>
						<div class="form-group">
								<label>จำกัดวันใช้งาน</label>
                            <input class="form-control" placeholder="30" name="Exp" type="text" value="{{ @vpnseven->Exp }}" required>
								</div>
						<div class="form-group">
                      <label>Squid Port</label>
                      <input class="form-control" placeholder="8000, 8080, 3128" name="info" type="text" value="{{ @vpnseven->info }}" required>
                        </div>                 												
												<div class="form-group">
                            <label>ไฟล์ VPN</label>
                            <input class="form-control" placeholder="ovpn" name="config" type="text" value="{{ @vpnseven->config }}" required>
                        </div>            
                        <div class="form-group">
                            <label>ราคา/เดือน</label>
                            <div class="input-group">
                                <span class="input-group-addon">ราคา</span>
                                <input class="form-control" placeholder="10" name="price" type="number" step="1" value="{{ @vpnseven->price }}" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Root Password</label>
                            <input class="form-control" placeholder="root" name="root_pass" type="password">
                        </div>
						
              </div>

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">ยืนยัน</button>
                       <check if="{{ @vpnseven->id }}">
                            <check if="{{ @vpnseven->active==1 }}">
                                <true>
                                    <a href="{{ @URI.'/active/0' }}" class="btn btn-warning">เซิฟว่าง</a>
                                </true>
                                <false>
                                    <a href="{{ @URI.'/active/1' }}" class="btn btn-success">เซิฟเต็ม</a>
                                </false>
                            </check>
                            <a href="{{ @URI.'/delete' }}" class="btn btn-danger hapus">ลบ</a>
                        </check>
                        <a href="/admin/vpnseven" class="btn btn-default">กลับ</a>
              </div>
            
            </form>
          </div>          
		</div>		                    
     </div>	     
         
    </section>
  </div>