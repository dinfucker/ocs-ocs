<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>
        <strong>๏ {{ @vpnseven->servername }}</strong>
        </h1>
        <ol class="breadcrumb">
            <li><a href="/dashboard"><i class="fa fa-dashboard"></i> HOME </a></li>
            <li><a href="/admin/vpnseven">All-Server</a></li>
            <li class="active"> รายชื่อบัญชี </li>
        </ol>
    </section>

    <section class="content">
        <div class="row">
                <div class="col-md-4">
                    <div class="box box-widget widget-user">
                        <div class="widget-user-header bg-black" style="background: url('/bootstrap/asset/img/check-hea.png') center center;">
                            <h3 class="widget-user-username"><B>เช็ครายละเอียดบัญชีที่เช่า<B></h3>
                            <h5 class="widget-user-desc">{{ @vpnseven->servername }}</h5>
                        </div>
                        <div class="widget-user-image">
                            <img class="img-circle" src="/bootstrap/asset/img/check-user.png" alt="User Avatar">
                        </div>
                        <div class="box-footer">
                            <div class="row">
                                <div class="col-sm-4 border-right">
                                    <center><span class="badge bg-red">ค้นหา ACCOUNT</span></center>
                                    <div class="table-responsive description-block">
                                        <ul class="nav nav-stacked">
                                            <table id="blackhole" class="table table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>USER</th>
                                                        <th>วันหมด</th>
                                                        <th>CREATE</th>
                                                        <th>สถานะ</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <check if="{{ @users }}">
                                                            <true>
                                                                <repeat group="{{ @users }}" value="{{ @user }}" counter="{{ @no }}">

                                                                    <td><span class="pull-right badge bg-maroon"> {{ @user->user }} </span></td>
                                                                    <td><span class="pull-right badge bg-purple"> {{ @user->exp }} </span></td>
                                                                    <td><span class="pull-right badge bg-green"> {{ @user->real }} </span></td>
                                                                    <td>
                                            
                                            <a href="{{ @URI.'/'.@user->uid }}/delete" class="btn btn-xs btn-danger hapus"> DELETE </a>
                                            <a href="{{ @URI.'/'.@user->uid }}" class="btn btn-xs btn-info"> EDIT </a>
                             
                                        </td>
                                                                    
                                                    </tr>
                                                    </repeat>
                                                    </true>
                                                    <false>
                                                        <tr>
                                                            <td class="text-muted text-center" colspan="6">ไม่มี ACCOUNT ที่ค้นหา</td>
                                                        </tr>
                                                    </false>
                                                </tbody>
                                                </check>
                                                </tr>
                                            </table>
                                        </ul>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

	</section>
</div>
