<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
     <check if="{{ @user->uid }}">
                    <true>
             <section class="content-header">         
                 <h1> ข้อมูลการสมัคร
                      </h1>
                    
      <ol class="breadcrumb">
        <li><a href="/dashboard"><i class="fa fa-dashboard"></i> HOME </a></li>
        <li><a href="/admin/vpnseven">List Server</a></li>
        <li class="active">ข้อมูลการสมัคร</li>
      </ol>
    </section>
     
					</true>
                    <false>
                      <section class="content-header">
                      <h1>
                        Add User
						                          </h1>
      <ol class="breadcrumb">
        <li><a href="/dashboard"><i class="fa fa-dashboard"></i> HOME </a></li>
        <li><a href="/admin/vpnseven">List Server</a></li>
        <li class="active">Add User</li>
      </ol>
    </section>
                    </false>
            </check>

 <section class="content"> 
    
	        <check if="{{ @message }}">     
				<div class="alert alert-{{ @message['type'] }} alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                {{ @message['data'] }}
              </div>
            </check>
    
		<div class="row">
        <div class="col-md-6">	
			<div class="box box-primary">
           	 <div class="box-header with-border">
               <i class="fa fa-user fa-fw"></i><h3 class="box-title">ข้อมูลบัญชี </h3>
            </div>
            
            <form role="form" action="{{ @URI }}" method="POST">
              <div class="box-body">
                        <div class="form-group">
                            <label>Username</label>
                            <input class="form-control" placeholder="Username" name="user" type="text" value="{{ @user->user }}" required>
                        </div>
                        <check if="{{ !@user->uid }}">
                            <div class="form-group">
                                <label>รหัสผ่าน</label>
                      <input class="form-control" placeholder="New Password" name="pass" type="password" required>
                            </div>
                            <div class="form-group">
                                <label>รหัสผ่าน อีกครั้ง</label>
                      <input class="form-control" placeholder="Re-enter Password" name="pass_confirmation" type="password" required>
                            </div>
                        </check>
              <div class="form-group">
                <label>วันหมดอายุ</label>

                <div class="input-group date">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input type="text" class="form-control pull-right" id="datepicker" name="exp" value="{{ @user->exp?@user->exp:date("Y/m/d",strtotime("+30 days")) }}">
                </div>
                
              </div>              
           </div>
              
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">บันทึก</button>
                        <check if="{{ @user->uid }}">
                            <true>
                                <check if="{{ @user->lock }}">
                                    <true>
                                        <a href="{{ @URI.'/active/1' }}" class="btn btn-success">ปลด</a>
                                    </true>
                                    <false>
                                        <a href="{{ @URI.'/active/0' }}" class="btn btn-warning">ล็อค</a>
                                    </false>
                                </check>
                                <a href="{{ @URI.'/delete' }}" class="btn btn-danger hapus">ลบ</a>
                            </true>
                            <false>
                                <a href="/admin/vpnseven/{{ @vpnseven->id }}/account/" class="btn btn-default">กลับ</a>
                            </false>
                        </check>
              </div>
            </form>
          </div>
          </div>		  
       
        <check if="{{ @user->uid }}">		  
        <div class="col-md-6">		  
         <div class="box box-primary">
            <div class="box-header with-border">
               <i class="fa fa-cog fa-spin"></i><h3 class="box-title">Change Password</h3>

            </div>
           
            <form role="form" action="{{ @URI }}" method="POST">
              <div class="box-body">
                        <div class="form-group">
                            <label>New Password</label>
                            <input class="form-control" placeholder="New Password" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>Re-enter New Password</label>
                            <input class="form-control" placeholder="Re-enter New Password" name="password_confirmation" type="password" required>
                        </div>
              </div>

              <div class="box-footer">
                <button type="submit" class="btn btn-primary"> SAVE </button>
     <a href="/admin/vpnseven/{{ @vpnseven->id }}/account/" class="btn btn-default pull-right"><i class="fa fa-arrow-left"></i> BACK </a>
              </div>
            </form>
      		    </div>
      		 </div>
			</check>
		  
       </div>		  
    </section>
  </div>