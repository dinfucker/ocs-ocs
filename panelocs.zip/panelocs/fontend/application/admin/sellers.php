<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
      ALL ACCOUNT
      </h1>
      <ol class="breadcrumb">
        <li><a href="/dashboard"><i class="fa fa-dashboard"></i> HOME </a></li>
        <li class="active">ALL ACCOUNT</li>
      </ol>
    </section>

    <section class="content">
	        <check if="{{ @message }}">     
				<div class="alert alert-{{ @message['type'] }} alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                {{ @message['data'] }}
              </div>
            </check>
   
      <div class="row">
        <div class="col-md-8">
          <div class="box box-light">
            <div class="box-header">
              <i class="fa fa-group fa-fw"></i><h3 class="box-title">รายชื่อ ทั้งหมด</h3>
			  <a href="{{ @URI }}/add" class="btn btn-info pull-right"><i class="fa fa-plus"></i> ADD </a>
            </div>
          
            <div class="box-body">
              <table id="blackhole" class="table table-bordered table-hover">
                <thead>
                <tr>
                                    	<th>ตั้งค่า</th>
                                    	<th>ชื่อ</th>
                                    	<th>เครดิต</th>                            
                </tr>
                </thead>
                <tbody>
                                <repeat group="{{ @sellers}}" value="{{ @seller }}" counter="{{ @no }}">
                                     <tr>
                                        <td> 
     <a href="/admin/seller/{{ @seller->id }}" class="btn btn-info">แก้ไข</a>&nbsp;
                                           
                                        </td>
                                        <td>{{ @seller->username }}</td>                                    
                                        <td>{{ @seller->banking }} <check if="{{ @seller->active==1 }}">
                                                <true>
<a href="/admin/seller/{{ @seller->id }}/active/0" class="btn btn-primary"> ล็อค </a>
                                                </true>
                                                <false>
<a href="/admin/seller/{{ @seller->id }}/active/1" class="btn btn-danger"> ปลด </a>
                           </false>
                         </check> 								
                       </td> 									
                     </tr>
                   </repeat>                                
                 <tfoot>
                <tr>
                  <th>ตั้งค่า</th>
                  <th>ชื่อ</th>
                  <th>เครดิต</th>                                 	    
                </tr>
                </tfoot>
              </table>               
             </div>
          </div>
        </div>

			</div>    
    </section>
  </div>