<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
    	<check if="{{ @server->id }}">
          <true>
          <h1>
          {{ @server->servername }}
          </h1>
          </true>
         <false>
         <h1>
          ADD SERVER
         </h1>
         </false>
        </check>
     
      <ol class="breadcrumb">
                 <check if="{{ @server->id }}">
                    <true>
        <li><a href="/dashboard"><i class="fa fa-fort-awesome"></i> HOME </a></li>
        <li><a href="/admin/server">รายชื่อเซิร์ฟเวอร์</a></li>
        <li class="active">แก้ไข {{ @server->servername }}</li>
                    </true>
                    <false>
                             <li><a href="/dashboard"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li><a href="/admin/server">รายชื่อเซิร์ฟเวอร์</a></li>
        <li class="active">เพิ่มเซิร์ฟเวอร์</li>
                    </false>
                </check>     
     
      </ol>
    </section>

    <section class="content">			
 		<div class="row">
       <div class="col-md-12 col-md-12 col-xs-12">
	        <check if="{{ @message }}">     
				<div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-info"></i>{{ @message['type'] }}</h4>
                {{ @message['data'] }}
              </div>
            </check>
        
		 <div class="box box-white">
            <div class="box-header with-border">
               <i class="fa fa-user fa-fw"></i><h3 class="box-title"> SERVER DETAIL </h3>
            </div>

            <form role="form" action="{{ @URI }}" method="POST">
              <div class="box-body">
                        <div class="form-group">
                            <label> SEVERNAME </label>
                            <input class="form-control" placeholder="Singapore" name="country" type="text" value="{{ @server->country }}" required>
                        </div>
						<div class="form-group">
                            <label> NAME CLOUD VPS </label>
                            <input class="form-control" placeholder="Digital Ocean" name="servername" type="text" value="{{ @server->servername }}" required>
                        </div>
                        <div class="form-group">
                            <label> HOSTNAME </label>
                            <input class="form-control" placeholder="dns-blackhole" name="host" type="text" value="{{ @server->host }}" required>
                        </div>
                        <div class="form-group">
                            <label> IP ADDRESS </label>
                            <input class="form-control" placeholder="0.0.0.0" name="ip" type="text" value="{{ @server->ip }}" required>
                        </div>
						<div class="form-group">
                            <label> SSH PORT </label>
                            <input class="form-control" placeholder="22,443" name="dropbear" type="text" value="{{ @server->dropbear }}" required>
                        </div>
						<div class="form-group">
                            <label> สมัครได้ต่อวัน </label>
                            <input class="form-control" placeholder="50" name="limitacc" type="text" value="{{ @server->limitacc }}" required>
                        </div>
                        <div class="form-group">
                            <label> VPN LIMIT </label>
                            <input class="form-control" placeholder="1" name="limitvpn" type="text" value="{{ @server->limitvpn }}" required>
                        </div>

                        <div class="form-group">
                            <label> SSH LIMIT </label>
                            <input class="form-control" placeholder="1" name="limitssh" type="text" value="{{ @server->limitssh }}" required>
                        </div>

						<div class="form-group">
							<label> จำกัดวันใช้งาน </label>
							<span class="form-control">{{ $server->Exp }}</span></span>
                            <input class="form-control" placeholder="30" name="Exp" type="hidden" value="30" required>
								</div>
						<div class="form-group">
                      <label> SQUID PORT </label>
                      <input class="form-control" placeholder="8000, 8080, 3128" name="info" type="text" value="{{ @server->info }}" required>
                        </div>                 												
												<div class="form-group">
                            <label> ไฟล์ VPN </label>
                            <input class="form-control" placeholder="ovpn" name="config" type="text" value="{{ @server->config }}" required>
                        </div>                  												
												<div class="form-group">
                            <label> ไฟล์ SSH </label>
                            <input class="form-control" placeholder="ehi" name="configssh" type="text" value="{{ @server->configssh }}" required>
                        </div>                 												
												<div class="form-group">
                            <label> ไฟล์ VPN PC </label>
                            <input class="form-control" placeholder="ovpn" name="configpc" type="text" value="{{ @server->configpc }}" required>
                        </div>         
                        <div class="form-group">
                            <label> ราคา/เดือน </label>
                            <div class="input-group">
                                <span class="input-group-addon">ราคา</span>
                                <input class="form-control" placeholder="10" name="price" type="number" step="1" value="{{ @server->price }}" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label> Root Password </label>
                            <input class="form-control" placeholder="root" name="root_pass" type="password">
                        </div>
						
              </div>

              <div class="box-footer">
                <button type="submit" class="btn btn-success pull-left"><i class="fa fa-ge"></i> ยืนยัน </button>
                       <check if="{{ @server->id }}">
                            <check if="{{ @server->active==1 }}">
                                <true>
                                    <a href="{{ @URI.'/active/0' }}" class="btn btn-warning">เซิฟว่าง</a>
                                </true>
                                <false>
                                    <a href="{{ @URI.'/active/1' }}" class="btn btn-success">เซิฟเต็ม</a>
                                </false>
                            </check>
                            <a href="{{ @URI.'/delete' }}" class="btn btn-danger hapus">ลบ</a>
                        </check>
                        <a href="/admin/server" class="btn btn-info pull-right"><i class="fa fa-home"></i> กลับ </a>
              </div>
            
            </form>
          </div>          
		</div>		                    
     </div>	     
         
    </section>
  </div>