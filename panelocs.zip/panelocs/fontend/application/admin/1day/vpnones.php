<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
  <?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
       All SERVER 1 วัน
      </h1>
    <ol class="breadcrumb">
        <li><a href="/dashboard"><i class="fa fa-fort-awesome"></i> HOME </a></li>
        <li class="active"> SERVER 1 วัน </li>
        <a href="{{ @URI }}/add" class="btn btn-success pull-right"><i class="fa fa-plus fa-fw"></i> ADD </a>
    <br />
    <br />
    </ol>
    </section>
 
    <section class="content">
  	  <div class="row">
  		<div class="col-md-6 col-md-6 col-xs-12">
	        <check if="{{ @message }}">     
				<div class="alert alert-{{ @message['type'] }} alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                {{ @message['data'] }}
              </div>
            </check>
         </div>   

        <repeat group="{{ @vpnones }}" value="{{ @vpnone }}">
        
 <div class="col-md-6 col-md-6 col-xs-12">
	 <div class="box box-white">
      <div class="box-header with-border">
         <i class="icon fa fa-ge"></i><h3 class="box-title"><b>{{ @vpnone->servername }}</b> {{ @vpnone->active==1?'':'( Locked )'}}</h3>
    <div class="box-tools pull-right">
           <button class="btn btn-box-tool bg-yellow" data-widget="collapse"><i class="fa fa-minus"></i></button>
    </div>
    </div>
 
        <div class="box-body">
                    <table class="table">
                        <tr>
                            <td><B> SERVER ID </B></td><td>{{ @vpnone->id }}</td>
                        </tr>
                        <tr>
                            <td><B> SERVER </B></td><td>{{ @vpnone->country }}</td>
                        </tr>
                        <tr>
                            <td><B> HOST </B></td><td>{{ @vpnone->host }}</td>
                        </tr>
                        <tr>
                            <td><B> IP ADDRESS </B></td><td>{{ @vpnone->ip }}</td>
                        </tr>
                        <tr>
                            <td><B> ราคา </B></td><td>{{ @vpnone->price }}</td>
                        </tr>
                    </table>
   		     </div>
     
        		<div class="box-footer text-center">                
                        <a href="{{ @URI.'/'.@vpnone->id }}" class="btn btn-primary"><i class="fa fa-edit fa-fw"></i> แก้ไข </a>
                        <a href="{{ @URI.'/'.@vpnone->id }}/account" class="btn btn-info"><i class="fa fa-group fa-fw"></i> รายชื่อ </a>
                        <check if="{{ @vpnone->id }}">
                            <check if="{{ @vpnone->active==1 }}">
                                <true>
                                    <a href="{{ @URI.'/'.@vpnone->id.'/active/0' }}" class="btn btn-success">ONLINE</a>
                             </true>
                           <false>
                           <a href="{{ @URI.'/'.@vpnone->id.'/active/1' }}" class="btn btn-danger">OFFLINE</a>
                     </false>
                  </check>
                        
               </div>
     	    </div>
    	   </div>
		 </repeat>               
		</div>
                                             
    </section>   
  </div>