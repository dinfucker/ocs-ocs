<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
 <div class="content-wrapper">
  	<check if="{{ @seller->id }}">
     <true>
    	<section class="content-header">   
         <h1> ACCOUNT EDIT </h1>
    			  <ol class="breadcrumb">
      			  <li><a href="/dashboard"><i class="fa fa-dashboard"></i> HOME </a></li>
        			<li><a href="/admin/seller">LIST ACCOUNT</a></li>
      			  <li class="active">ACCOUNT EDIT</li>
    			  </ol>
  			  </section>
					</true>
          <false>
        <section class="content-header">   
         <h1> เพิ่มบัญชี </h1>
     			 <ol class="breadcrumb">
     			   <li><a href="/dashboard"><i class="fa fa-dashboard"></i> HOME </a></li>
      			  <li><a href="/admin/seller">List Seller</a></li>
      			  <li class="active">ADD ACCOUNT</li>
     			 </ol>
 			   </section>
       </false>
    </check>

    <section class="content">
	        <check if="{{ @message }}">     
				<div class="alert alert-{{ @message['type'] }} alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                {{ @message['data'] }}
              </div>
            </check>
			
		<div class="row">
        <div class="col-md-6">	
			         <div class="box box-primary">
            <div class="box-header with-border">
               <i class="fa fa-user fa-fw"></i><h3 class="box-title">สร้างบัญชีล็อกอิน</h3>
            </div>
            
            <form role="form" action="{{ @URI }}" method="POST">
              <div class="box-body">
              			<div class="form-group">
                            <label>Email</label>
                            <input class="form-control" placeholder="Email" name="email" type="text" value="{{ @seller->email }}" required>
                        </div>
                         <div class="form-group">
                            <label>Username</label>
                            <input class="form-control" placeholder="Username" name="username" type="text" value="{{ @seller->username }}" required>
                        </div>
                        <check if="{{ !@seller->id }}">
                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" placeholder="New Password" name="password" type="password" required>
                            </div>
                            <div class="form-group">
                                <label>Re-enter Password</label>
                                <input class="form-control" placeholder="Re-enter Password" name="password_confirmation" type="password" required>
                            </div>
                        </check>
                        <div class="form-group">
                            <label>เติมเงิน</label>
                            <div class="input-group">
                                <span class="input-group-addon">ยอดเงิน </span>
                                <input class="form-control" placeholder="100" name="banking" type="number" step="1" value="{{ @seller->banking }}" required>
                            </div>
                        </div>
						
              </div>
              

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">ยืนยัน</button>
                        <check if="{{ @seller->id }}">
                            <true>
                                <check if="{{ @seller->active==1 }}">
                                    <true>
                                        <a href="{{ @URI.'/active/0' }}" class="btn btn-warning">ล็อค</a>
                                    </true>
                                    <false>
                                        <a href="{{ @URI.'/active/1' }}" class="btn btn-success">ปลด</a>
                                    </false>
                                </check>
                                <a href="{{ @URI.'/delete' }}" class="btn btn-danger hapus">ลบ</a>
                            </true>
                            <false>
                                <a href="/admin/seller" class="btn btn-default">กลับ</a>
                            </false>
                        </check>
				              </div>
            </form>
          </div>
          </div>

       <check if="{{ @seller->id }}">		  
        <div class="col-md-6">		  
         <div class="box box-danger">
            <div class="box-header with-border">
               <i class="fa fa-cog fa-spin"></i><h3 class="box-title">เปลี่ยนรหัสผ่าน</h3>
            </div>
            
            <form role="form" action="{{ @URI }}" method="POST">
              <div class="box-body">
                        <div class="form-group">
                            <label>รหัสผ่านใหม่</label>
                            <input class="form-control" placeholder="New Password" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>รหัสผ่านอีกครั้ง</label>
                            <input class="form-control" placeholder="Re-enter New Password" name="password_confirmation" type="password" required>
                        </div>
              </div>

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">ยืนยัน</button>
              <a href="/admin/seller" class="btn btn-default pull-right"><i class="fa fa-arrow-left fa-fw"></i> กลับ</a>
            			  </div>
            			</form>
         			 </div>
       			 </div>
					</check>
		  
       </div>		  
    </section>    
  </div>