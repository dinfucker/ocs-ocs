<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
      TOPUP ACCOUNT
      </h1>
      <ol class="breadcrumb">
        <li><a href="/dashboard"><i class="fa fa-dashboard"></i> HOME </a></li>
        <li class="active">TOPUP ACCOUNT</li>
      </ol>
    </section>

    <section class="content">
	        <check if="{{ @message }}">     
				<div class="alert alert-{{ @message['type'] }} alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                {{ @message['data'] }}
              </div>
            </check>
   
   <div class="row">   
      <div class="col-md-12">		  
         <div class="box box-danger">
            <div class="box-header with-border">
                <i class="fa fa-money fa-fw"></i><h3 class="box-title"> TOPUP ID ACCOUNT </h3>
            </div>

						<form role="form" action="/admin/seller/deposit" method="POST">
              <div class="box-body">
                 <div class="form-group">
                    <label> ID ACCOUNT ที่จะเพิ่ม </label>															
                       <div class="input-group">
                         <span class="input-group-addon"> ID. </span>                       
													 <input class="form-control" placeholder="1" name="id" type="number" required>
                          </div>                        
                        </div>
                        <div class="form-group">
                            <label>จำนวน</label>
                            <div class="input-group">
                                <span class="input-group-addon"> เงิน. </span>
                                <input class="form-control" placeholder="1" name="deposit" type="number" min="1" step="1" required>
                            </div>
                        </div>
              </div>

              <div class="box-footer">
                <button type="submit" class="btn btn-primary"><i class="fa fa-paw"></i> ยืนยัน</button>
                <a href="/admin/server" class="btn btn-warning"><i class="fa fa-home"></i> ย้อนกลับ </a>
                <button type="reset" class="btn btn-danger pull-right"> Reset</button>                        
              </div>              
            </form>
       
          </div>
 				 </div>

      <div class="col-md-12">		  
         <div class="box box-danger">
            <div class="box-header with-border">
                <i class="fa fa-money fa-fw"></i><h3 class="box-title"> TOPUP USER ACCOUNT </h3>
            </div>

						<form role="form" action="/admin/seller/userdeposit" method="POST">
              <div class="box-body">
                 <div class="form-group">
                    <label>USERNAME ที่จะเพิ่ม</label>															
                       <div class="input-group">
                         <span class="input-group-addon"> USER. </span>                       
													 <input class="form-control" placeholder="admin" name="username" type="text" required>
                          </div>                        
                        </div>
                        <div class="form-group">
                            <label>จำนวน</label>
                            <div class="input-group">
                                <span class="input-group-addon"> เงิน. </span>
                                <input class="form-control" placeholder="1" name="userdeposit" type="number" min="1" step="1" required>
                            </div>
                        </div>
              </div>

              <div class="box-footer">
                <button type="submit" class="btn btn-primary"><i class="fa fa-paw"></i> ยืนยัน</button>
                <a href="/admin/server" class="btn btn-warning"><i class="fa fa-home"></i> ย้อนกลับ </a>
                <button type="reset" class="btn btn-danger pull-right"> Reset</button>                        
              </div>              
            </form>
       
          </div>
 				 </div>

			</div>    
    </section>
  </div>