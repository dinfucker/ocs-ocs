<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        เช็คสถานะและวันหมดอายุ
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-fort-awesome"></i> HOME </a></li>
        <li class="active">userstatus</li>
      </ol>
    </section>

    <section class="content">               
      <div class="row">
        <div class="col-md-3">        
          <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title text-center"> <B>เช็คสถานะบัญชี </B></h3>
              <div class="box-tools">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="box-body no-padding">
              <ul class="nav nav-pills nav-stacked">
                <li><a href="/user/1/status"><i class="fa fa-mixcloud"></i> <B> TH-1.BLACKHOLE</B>
                  <span class="badge bg-red pull-right"> เช็ครายละเอียด </span></a></li>
                  
                  <li><a href="/user/2/status"><i class="fa fa-mixcloud"></i> <B> TH-2.BLACKHOLE</B>
                  <span class="badge bg-green pull-right"> เช็ครายละเอียด </span></a></li>
                  
                  <li><a href="/user/3/status"><i class="fa fa-mixcloud"></i> <B> TH-3.BLACKHOLE</B>
                  <span class="badge bg-blue pull-right"> เช็ครายละเอียด </span></a></li>
                  
                  <li><a href="/user/4/status"><i class="fa fa-mixcloud"></i> <B> TH-4.BLACKHOLE</B>
                  <span class="badge bg-yellow pull-right"> เช็ครายละเอียด </span></a></li>
                  
                  <li><a href="/user/5/status"><i class="fa fa-mixcloud"></i> <B> TH-5.BLACKHOLE</B>
                  <span class="badge bg-purple pull-right"> เช็ครายละเอียด </span></a></li>
                  
                  <li><a href="/user/6/status"><i class="fa fa-mixcloud"></i> <B> TH-6.BLACKHOLE</B>
                  <span class="badge bg-maroon pull-right"> เช็ครายละเอียด </span></a></li>
                  
                  <li><a href="/user/7/status"><i class="fa fa-mixcloud"></i> <B> TH-7.BLACKHOLE</B>
                  <span class="badge bg-red pull-right"> เช็ครายละเอียด </span></a></li>
                  
                  <li><a href="/user/8/status"><i class="fa fa-mixcloud"></i> <B> TH-8.BLACKHOLE</B>
                  <span class="badge bg-blue pull-right"> เช็ครายละเอียด </span></a></li>
                  
                  <li><a href="/user/9/status"><i class="fa fa-mixcloud"></i> <B> TH-9.BLACKHOLE</B>
                  <span class="badge bg-green pull-right"> เช็ครายละเอียด </span></a></li>
                  
                  <li><a href="/user/10/status"><i class="fa fa-mixcloud"></i> <B> TH-10.BLACKHOLE</B>
                  <span class="badge bg-maroon pull-right"> เช็ครายละเอียด </span></a></li>
                
              </ul>
            </div>
            </div>
          </div>                       
      </div>
    </section>
</div>