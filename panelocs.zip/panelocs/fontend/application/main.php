<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div class="content-wrapper">
<section class="content-header">
   <h1>
      MOOVPN
   </h1>
   <ol class="breadcrumb">
      <li><a href="/dashboard"><i class="fa fa-fort-awesome active"></i> DASHBOARD </a></li>
   </ol>
</section>
<section class="content">
   <div class="row">
      <div class="col-md-12">
         <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-left">
               <li class="active"><a href="#tab_1-1" data-toggle="tab">ประกาศ</a></li>
               <li><a href="#tab_2-2" data-toggle="tab">กิจกรรม</a></li>
            </ul>
            <br>
            <div class="tab-content">
               <div class="tab-pane active" id="tab_1-1">
                  <p>                  
                  <h4><b>แจ้ง....</b></h4>								
                  <p> moovpn บริการเช่าอินเตอร์เน็ตระบบ vpn <br> หากพบข้อสงสัยสามารถ สอบถามได้ข้างล่างนี้ </p>

                  <h5>#หมายเหตุ: มีปัญหาด้านอื่นๆ  <b><a href="https://m.me/MooChomtong"> กดตรงนี้</a></b></h5>
               </div>
               <div class="tab-pane" id="tab_2-2">
                  <p>
									<h4><b> ยังไม่เปิด .. </b></h4>
                  <p> 📣📣📣  ก็เช่าเซิฟฟรี 1 วัน ได้ไม่จำกัด </p>
									<p> หากต้องการอยากรู้ รายละเอียดของเซิฟเวอร์ไหน สามารถเช่าเซิฟเวอร์ฟรี 1 วัน มาทดลองได้เลยคับ (ไม่เสียเงินครับ) ชอบเซิฟไหนค่อยเช่า หรือใครไม่อยากเสียเงิน ก็แค่เติมเงินไว้ใน ACCOUNT 20 บาท ก็ได้ครับ ขยันมาสมัครเอาก็แล้วกัน </p>
                  <h5>#หมายเหตุ: มีปัญหาด้านอื่นๆ  <b><a href="https://m.me/MooChomtong"> กดตรงนี้</a></b></h5>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="row">
     <div class="col-md-6 col-md-6 col-xs-12">
         <div class="info-box bg-light">
            <span class="info-box-icon"><i class="fa fa-slideshare"></i></span>
            <div class="info-box-content">
               <span class="info-box-text">USERNAME <span class="info-box-text pull-right"> ID ACCOUNT </span></span> 
               <span class="info-box-number">{{ @me->username }} <span class="info-box-number pull-right">{{ @me->id }}</span></span>
               <div class="progress">
                  <div class="progress-bar" style="width: 0%"></div>
               </div>
               <span class="progress-description">
                <a href="/profile"> Profile <i class="fa fa-shield"></i></a>
               </span>
            </div>
         </div>
      </div>
      <div class="col-md-6 col-md-6 col-xs-12">
         <div class="info-box bg-dark">
            <span class="info-box-icon"><i class="fa fa-drupal"></i></span>
            <div class="info-box-content">
               <span class="info-box-text">ยอดเงินคงเหลือ</span>
               <span class="info-box-number">{{ @me->banking }} บาท</span>
               <div class="progress">
                  <div class="progress-bar" style="width: 100%"></div>
               </div>
               <span class="progress-description">
               <a href="/wallet"> <i class="fa fa-codiepie pull-right"> เติมเงิน wallet </i></a>
               <a href="/money"> <i class="fa fa-codepen pull-left"> เติมเงิน money </i></a>
               </span>
            </div>
         </div>
      </div>
	</section>
</div>