<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        TRUE WALLET
      </h1>
    <ol class="breadcrumb">
        <li><a href="/dashboard"><i class="fa fa-fort-awesome"></i> HOME </a></li>
        <li class="active">TRUE WALLET</li>
    </ol>
    </section>

    <section class="content">
       <div class="row">
	        <check if="{{ @message }}">     
				<div class="alert alert-{{ @message['type'] }} alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                {{ @message['data'] }}
              </div>
            </check>
   
		  <div class="col-md-12">
          <div class="box box-widget widget-user">
         	<div class="widget-user-header bg-black" style="background: url('/bootstrap/img/blackhole-3.jpg') center center;">
              <h5 class="widget-user-username" style="font-size: 16px;"> <B> USERNAME </B><span class="pull-right"><B> ยอดเงินคงเหลือ </span></h5>
              <h4 class="widget-user-desc"><span style="font-size: 14px;" class="badge bg-purple"><B>  {{ $me->username }} </B></span><span style="font-size: 14px;" class="pull-right badge bg-navy"><B>  {{ $me->banking }} บาท </B></span></h4>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="/bootstrap/img/twallet.jpg" alt="User Avatar">
            </div>
 
				 <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">เบอร์สำหรับเติมเงิน</span></span>
         </div>
         
              <ul class="nav nav-stacked">
                <li><a href="#"><B> ชื่อ WALLET </B><span class="pull-right"><B> เบอร์ WALLET </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-aqua"> ธณพล เชื่อมทอง </span> <span style="font-size: 16px;" class="pull-right badge bg-maroon"> 062-9804107 </span></a></li>                                        
              </ul>
            </div>

	<div class="box-footer">
		<form action="/wallets/input.php" method="post">
           <center><span class="description-text"><span style="font-size: 12px;" class="badge bg-light"><B> USERNAME {{ $me->username }} </B></span></span></center>
        <br />
    		<div class="form-group">
				<input name="user" type="hidden" value="{{ @me->username }}">
				<button type="submit" name="submit" class="btn btn-success pull-left"><i class="fa fa-lock"></i> กดถัดไปเพื่อยืนยัน </button>
           <a href="/dashboard" class="btn btn-warning pull-right"><i class="fa fa-home"></i> ย้อนกลับ</a>
	
 						</div>
 						</form>
					 </div>        
 				</div> 
			</div>
                   
            
            </div>
          </div>
        </div>
      </div>
    </section>
</div>