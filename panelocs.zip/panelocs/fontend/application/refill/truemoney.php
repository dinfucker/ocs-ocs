<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
       TRUE MONEY
      </h1>
    <ol class="breadcrumb">
        <li><a href="/dashboard"><i class="fa fa-fort-awesome"></i> HOME </a></li>
        <li class="active">TRUE MONEY</li>
    </ol>
    </section>

    <section class="content">
       <div class="row">
	        <check if="{{ @message }}">     
				<div class="alert alert-{{ @message['type'] }} alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                {{ @message['data'] }}
              </div>
            </check>
   
		  <div class="col-md-12">
          <div class="box box-widget widget-user">
         	<div class="widget-user-header bg-black" style="background: url('/bootstrap/asset/img/photo1.jpg') center center;">
              <h2 class="widget-user-username"><span style="font-size: 20px;"><B> USERNAME </B></span><span class="pull-right"><span style="font-size: 20px;"><B> ยอดเงินคงเหลือ </B></span></span></h2>
              <h4 class="widget-user-desc"><span style="font-size: 14px;" class="badge bg-purple"><B>  {{ $me->username }} </B></span><span style="font-size: 14px;" class="pull-right badge bg-navy"><B>  {{ $me->banking }} บาท </B></span></h4>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="/bootstrap/img/money.jpg" alt="User Avatar">
            </div>
 
				 <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">รายละเอียด</span></span>
         </div>
              <ul class="nav nav-stacked text-center">
                <li><a href="#"><B> <span style="font-size: 16px;"> เติมด้วยบัตร true money มีค่าทำเนียม 14%. </span></B></span></a></li>
                <li><a href="#"> <span style="font-size: 16px;"> ตัวอย่าง เติม 50 บาท จะได้ 43 บาท </span></a></li>                                        
              </ul>
            </div>

		<div class="box-footer">
    	<div class="form-group">
						<input name="tmn_password" type="number" id="tmn_password" maxlength="14" class="form-control" placeholder="กรอกบัตรทรูมันนี่ 14 หลัก">
				 <input name="ref1" type="hidden" value="{{ @me->id }}" id="ref1">
				 <input name="ref2" type="hidden" value="{{ @me->username }}" id="ref2">
				 <input name="ref3" type="hidden" value="{{ @me->email }}" id="ref3">    
					</div>
						<center><button type="button" class="btn btn-green btn-rounded waves-effect waves-light" onclick="submit_tmnc()"><i class="fa fa-btc"></i> ยืนยันเติมเงิน</button>
           <a href="/dashboard" class="btn btn-red btn-rounded waves-effect waves-light"><i class="fa fa-home"></i> ย้อนกลับ</a>					
								</center>
 						</div>
					 </div>        
 				</div> 
			</div>
            
            </div>
          </div>
        </div>
      </div>
    </section>
</div>
<script type="text/javascript" src='https://www.tmtopup.com/topup/3rdTopup.php?uid=211704'></script>
