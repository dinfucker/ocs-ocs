<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>  
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
 {{ @vpnseven->servername }}
      </h1>
      <ol class="breadcrumb">
        <li><a href="/dashboard"><i class="fa fa-fort-awesome"></i> HOME </a></li>
        <li><a href="/client/vpnseven"><i class="fa fa-jsfiddle"></i> OPENVPN SSH </a></li>
        <li class="active">{{ @vpnseven->servername }}</li>
      </ol>
    </section>

    <section class="content">
   <div class="row">
    <div class="col-sm-6 col-md-4 col-lg-3">     
	    <check if="{{ @message }}">     
				<div class="alert alert-{{ @message['type'] }} alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                {{ @message['data'] }}
              </div>
            </check>
       </div>

           <div class="col-md-12">
                <div class="box box-widget widget-user">
                	<div class="widget-user-header bg-black" style="background: url('/bootstrap/asset/img/photo1.jpg') center center;">
              <h3 class="widget-user-username"> {{ @vpnseven->servername }}</b> {{ @vpnseven->active==1?'':'( เต็ม )'}}</h3>
              <h4 class="widget-user-desc">{{ @vpnseven->Exp }} วัน   {{ @vpnseven->price }} บาท</h4>
              
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="/bootstrap/asset/img/user3-128x128.png" alt="User Avatar">
            </div>
 
				 <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">รายละเอียด</span></span>
         </div>
         
              <ul class="nav nav-stacked">
                <li><a href="#"><B> เซิร์ฟเวอร์ </B><span class="pull-right"><B> IP HOST </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-aqua"> {{ @vpnseven->country }} </span> <span style="font-size: 16px;" class="pull-right badge bg-purple"><B> แสดงเมื่อเช่าแล้ว </B></span></a></li>
                
                <li><a href="#"><B> SSH PORT </B><span class="pull-right"><B> จำกัดเชื่อมต่อ </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-maroon"> {{ @vpnseven->dropbear }} </span><span style="font-size: 16px;" class="pull-right badge bg-navy"> VPN {{ @vpnseven->limitvpn }} </span></a></li>
                
                <li><a href="#"><B> วันใช้งาน </B><span class="pull-right"><B> จำกัดการเช่า </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-purple"> {{ @vpnseven->Exp }} วัน</span><span style="font-size: 16px;" class="pull-right badge bg-blue"> {{ @vpnseven->limitacc }} บัญชี/วัน </span></a></li>
                
                <li><a href="#"><B> ราคา </B><span class="pull-right"><B> สถานะเซิร์ฟเวอร์ </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-orange"> {{ @vpnseven->price }} บาท </span><span style="font-size: 16px;" class="pull-right badge bg-green"> {{ @vpnseven->Status }} </span></a></li>
                
              </ul>
            </div>

	<div class="box-footer">
           <center><span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">กำหนดชื่อและรหัสผ่านสำหรับใช้งาน</span></span></center>
         <br>
			<form role="form" action="{{ @URI }}" method="POST">
					<div class="form-group">
							<label for="user">ชื่อบัญชี</label>
							<input type="text" name="user" class="form-control" minlength="5" placeholder="อย่างน้อย 5 ตัวอักษร" required>
						</div>
						<div class="form-group">
							<label for="pass">รหัสผ่าน </label>
							<input class="form-control" placeholder="อย่างน้อย 5 ตัวอักษร" name="pass" minlength="5" type="text" required>
						</div>
            <div class="form-group">
							 <label for="pass_confirmation">ยืนยันรหัสผ่าน </label>
							<input class="form-control" placeholder="ยืนยันรหัสผ่านอีกครั้ง" name="pass_confirmation" minlength="5" type="text" required>
						 </div>                     
                  <div class="form-group text-center">
									<button class="btn btn-success"><i class="fa fa-mixcloud"></i> ยืนยัน</button>                   
                        <a href="/client/vpnseven" class="btn btn-warning"><i class="fa fa-fort-awesome"></i> ย้อนกลับ</a>
										</div>
    								 </form>
 								</div>
							</div>        
 					  </div> 
					</div>
 
    </section>
  </div>