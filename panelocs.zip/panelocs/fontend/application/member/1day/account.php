<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        FREE SEVER SUCCESS
      </h1>
      <ol class="breadcrumb">
        <li><a href="/ddashboard"><i class="fa fa-fort-awesome"></i> HOME </a></li>
        <li><a href="/client/server">SUCCESS</a></li>
        <li class="active">สมัครเซิร์ฟเวอร์ฟรีเรียบร้อย</li>
      </ol>
    </section>

    <section class="content">
     <div class="row">  
     	<div class="col-sm-6 col-md-4 col-lg-3">
	        <check if="{{ @message }}">     
				<div class="alert alert-{{ @message['type'] }} alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                {{ @message['data'] }}
              </div>
            </check>
            </div>
            
		    <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="box box-widget widget-user">
                	<div class="widget-user-header bg-black" style="background: url('/bootstrap/asset/img/photo1.jpg') center center;">
            		  <h3 class="widget-user-username"><B> {{ @vpnone->servername }} <span style="font-size: 16px;" class="pull-right badge bg-green"> {{ @vpnone->Status }} </span><B></h3>
        		      <h4 class="widget-user-desc"><B>สมัครบัญชีและชำระเงิน เรียบร้อย <B></h4>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="/bootstrap/asset/img/user3-128x128.png" alt="User Avatar">
            </div>
                          
   	  <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">รายละเอียด</span></span>
         </div>
         
              <ul class="nav nav-stacked">
          	  <li><a href="#"><B> USERNAME </B><span class="pull-right"><B> PASSWORD </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-aqua"> {{ @user->user }} </span> <span style="font-size: 16px;" class="pull-right badge bg-purple"> {{ @user->pass }} </span></a></li>
                
                <li><a href="#"><B> IP ADDRS </B><span class="pull-right"><B> HOSTNAME </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-maroon"> {{ @vpnone->host }} </span><span style="font-size: 16px;" class="pull-right badge bg-navy"> {{ @vpnone->ip }} </span></a></li>
                
                <li><a href="#"><B> SSH PORT </B><span class="pull-right"><B> SQUID PROXY </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-purple"> {{ @vpnone->dropbear }} </span><span style="font-size: 16px;" class="pull-right badge bg-blue"> {{ @vpnone->info }} </span></a></li>
                
                <li><a href="#"><B> วันหมดอายุ </B><span class="pull-right"><B> จำกัดการเชื่อมต่อ </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-orange"> {{ \Webmin::exp_decode(@user->expire) }} </span><span style="font-size: 16px;" class="pull-right badge bg-green"> VPN {{ @vpnone->limitvpn }} </span></a></li>
                
              </ul>
            </div>
			
			<div class="box-footer text-center"> 
					<a href="{{ '/upload/vpn/'.@vpnone->config }}" class="btn btn-success"><i class="glyphicon glyphicon-cloud-download"></i> VPN OVPN </a> 
					<a href="{{ '/upload/ssh/'.@vpnone->configssh }}" class="btn btn-success"><i class="glyphicon glyphicon-cloud-download"></i> SSH EHI </a> 
               	<a href="/dashboard" class="btn btn-warning btn-fill pull-left"> HOME </a>
              </div>
          </div>        
        </div>
     
    </div>
       
    </section>
  </div>