<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
       OPENVPN SSH 15 วัน
      </h1>
      <ol class="breadcrumb">
       <li><a href="/dashboard"><i class="fa fa-fort-awesome"></i> HOME </a></li>
        <li class="active"><i class="fa fa-modx"></i> OPENVPN SSH </li>
       </ol>
     </section>

     <section class="content">
            <div class="row">
                <check if="{{ @message }}">
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="alert alert-success alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <h4><i class="icon fa fa-info"></i></h4> {{ @message['data'] }}
                        </div>
                    </div>
                </check>
				<repeat group="{{ @vpntrees }}" value="{{ @vpntree }}">
                <div class="col-sm-6 col-md-6 col-lg-12">
                    <div class="box box-solid">                     
                        <div class="box-body no-padding">
                           <ul class="nav nav-pills nav-stacked">
                              <li><a href="{{ @URI.'/'.@vpntree->id }}"><span class="widget-user-username"><B><i class="fa fa-modx"></i> {{ @vpntree->servername }} 🆗 </B><span class="badge bg-black pull-right"> เลือกเช่าเซิฟนี้ </span></span></a>
                                
                       </li>
                     </ul>                              

                 </div>
               </div>
             </div>

         </repeat>
      </div>
   </section>
</div>