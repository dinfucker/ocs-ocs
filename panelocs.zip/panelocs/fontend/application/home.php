<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="wrapper">
    <header class="main-header">
        <a href="/dashboard" class="logo">
        <span class="logo-mini"> BH</span>
        <span class="logo-md"><b> MOO </b>VPN</span>
        </a>
        <nav class="navbar navbar-static-top">
            <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span> MENU
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </a>
            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">
                    <li class="dropdown messages-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="fa fa-gg-circle"></i>
                        <span class="label label-success">เติม</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="header">เลือกระบบการเติมเงิน</li>
                            <li>
                                <ul class="menu">
                                    <li>
                                        <a href="/wallet">
                                            <div class="pull-left">
                                                <img src="/bootstrap/img/twallet.jpg" class="img-circle" alt="User Image">
                                            </div>
                                            <h4>
                                                TRUE WALLET
                                                <small><i class="fa fa-clock-o"></i> ทรูวอเล็ต </small>
                                            </h4>
                                            <p>เติมกี่บาทก็ได้ จัดยาวๆแบบ NonStop</p>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="/money">
                                            <div class="pull-left">
                                                <img src="/bootstrap/img/money.jpg" class="img-circle" alt="User Image">
                                            </div>
                                            <h4>
                                                TRUE MONEY
                                                <small><i class="fa fa-clock-o"></i> ทรูมันนี่ </small>
                                            </h4>
                                            <p>มีค่า ทำเนียม 14% หักแบบว่าร้องเลยอ่ะ </p>
                                        </a>
                                    </li>
                                </ul>
                             </li>
                          <li class="footer"><a href="#">TOPUP</a></li>
                       </ul>
                    </li>
                    <li class="dropdown messages-menu">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="fa fa-shield"></i>
                        <span class="label label-info">P</span>
                        </a>
                		 <ul class="dropdown-menu">
                          <li class="header"> PROFILE </li>
                            <li>
                                <ul class="menu">
                                    <li>
                                        <a href="/profile">
                                            <div class="pull-left">
											 <img src="/bootstrap/img/blackhole2_1.jpg" class="img-circle" alt="User Image">
                                            </div>
                                            <h4>
                                                {{ @me->username }}
                                                <small><i class="fa fa-circle text-success"></i> ONLINE </small>
                                            </h4>
                                            <p>{{ @me->email }}</p>
                                        </a>
                                    </li>
                                    <li>
									 <div class="text-center">
                                      <h4>
										เงินของคุณ : <small><i class="fa fa-clock-o"></i> ล่าสุด </small>
										<h1><b> {{ @me->banking }} บาท </b></h1>
                                     </h4>
                                   </div>
                                   
                                </li>
                             </li>
                          <li class="footer">
							<a href="/logout" class="pull-right"><b> ออกจากระบบ </b></a>
							<a href="/profile" class="pull-left"><b> เปลี่ยนรหัสผ่าน </b></a>
						  </li>
                       </ul>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <aside class="main-sidebar">
        <section class="sidebar">
            <div class="user-panel">
                <div class="pull-left image">
                    <img src="/bootstrap/img/blackhole2_1.jpg" class="img-circle" alt="User Image">
                </div>
                <div class="pull-left info">
                    <p>{{ @me->username }}</p>
                    <a href="#"><i class="fa fa-circle text-success"></i> {{ @me->type==1?'ADMIN':'MEMBER' }}</a>
                </div>
            </div>
            <ul class="sidebar-menu">
                <li class="header">เมนู</li>
                <li><a href="/dashboard"><i class="fa fa-fort-awesome"></i> <span> DASHBOARD </span></a></li>
                <check if="{{ @me->type==1 }}">
                    <true>
                        <li class="treeview">
                            <a href="#">
                            <i class="fa fa-ge"></i> <span> SEVER VPN SSH </span>
                            <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                            </span>
                            </a>
                            <ul class="treeview-menu">
                                <li class="treeview">
                                    <a href="#">
                                    <i class="fa fa-mixcloud"></i> <span> SEVER 30 วัน </span>
                                    <span class="pull-right-container">
                                    <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                    </a>
                                    <ul class="treeview-menu">
                                        <li><a href="/admin/server"><i class="fa fa-cloud-upload"></i> ALL SEVER </a></li>
                                        <li><a href="/admin/server/add"><i class="fa fa-cloud-download"></i> ADD SERVER </a></li>
                                    </ul>
                                </li>
                                <li class="treeview">
                                    <a href="#">
                                    <i class="fa fa-modx"></i> <span> SEVER 15 วัน </span>
                                    <span class="pull-right-container">
                                    <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                    </a>
                                    <ul class="treeview-menu">
                                        <li><a href="/admin/vpntree"><i class="fa fa-cloud-upload"></i> ALL SEVER </a></li>
                                        <li><a href="/admin/vpntree/add"><i class="fa fa-cloud-download"></i> ADD SERVER </a></li>
                                    </ul>
                                </li>
                                <li class="treeview">
                                    <a href="#">
                                    <i class="fa fa-jsfiddle"></i> <span> SEVER 7 วัน </span>
                                    <span class="pull-right-container">
                                    <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                    </a>
                                    <ul class="treeview-menu">
                                        <li><a href="/admin/vpnseven"><i class="fa fa-cloud-upload"></i> ALL SEVER </a></li>
                                        <li><a href="/admin/vpnseven/add"><i class="fa fa-cloud-download"></i> ADD SERVER </a></li>
                                    </ul>
                                </li>
                                <li class="treeview">
                                    <a href="#">
                                    <i class="fa fa-send-o"></i> <span> SEVER 1 วัน ฟรี </span>
                                    <span class="pull-right-container">
                                    <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                    </a>
                                    <ul class="treeview-menu">
                                        <li><a href="/admin/vpnone"><i class="fa fa-cloud-upload"></i> ALL SEVER </a></li>
                                        <li><a href="/admin/vpnone/add"><i class="fa fa-cloud-download"></i> ADD SERVER </a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="treeview">
                            <a href="#">
                            <i class="fa fa-first-order"></i> <span> ACCOUNT </span>
                            <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                            </span>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="/admin/seller"><i class="fa fa-user-md"></i> ALL ACCOUNT </a></li>
                                <li><a href="/admin/seller/add"><i class="fa fa-user-plus"></i> ADD ACCOUNT </a></li>
                            </ul>
                        </li>
                        <li class="treeview">
                            <a href="#">
                            <i class="fa fa-joomla"></i> <span> TOPUP ACCOUNT </span>
                            <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                            </span>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="/admin/histrory"><i class="fa fa-slideshare"></i> ประวัติการเติมเงิน </a></li>
                                <li><a href="/admin/refill"><i class="fa fa-buysellads"></i> TOPUP ACCOUNT </a></li>
                            </ul>
                        </li>
                    </true>
                    <false>
                        <li class="treeview">
                            <a href="#">
                            <i class="fa fa-ge"></i>
                            <span> เช่า VPN SSH </span>
                            <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                            </span>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="/client/server"><i class="fa fa-mixcloud"></i> <span> VPN SSH 30 วัน </span></a></li>
                                <li><a href="/client/vpntree"><i class="fa fa-modx"></i> <span> VPN SSH 15 วัน </span></a></li>
                                <li><a href="/client/vpnseven"><i class="fa fa-jsfiddle"></i> <span> VPN SSH 7 วัน </span></a></li>
                                <li><a href="/client/vpnone"><i class="fa fa-send-o"></i> <span> VPN SSH 1 วัน (ฟรีปิดชั่วคราว) </span></a></li>
                            </ul>
                        <li class="treeview">
                            <a href="#">
                            <i class="fa fa-user-md"></i>
                            <span>เช็ครายละเอียด USER</span>
                            <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                            </span>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="/userstatus"><i class="fa fa-slideshare"></i> <span> เช็ควันใช้งาน </span></a></li>
                                <li><a href="/"><i class="fa fa-drupal"></i> <span> เช็คผู้ใช้งานที่ออนไลน์ (close)</span></a></li>
                            </ul>
                        <li class="treeview">
                            <a href="#">
                            <i class="fa fa-buysellads"></i>
                            <span>เติมเงิน TOPUP </span>
                            <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                            </span>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="/wallet"><i class="fa fa-codiepie"></i> <span> TRUE WALLET </span></a></li>
                                <li><a href="/money"><i class="fa fa-codepen"></i> <span> TRUE MONEY </span></a></li>
                            </ul>
                				<li><a href="/upload/all/BLACKHOLE-.zip" ><i class="fa fa-viadeo-square" ></i><span> ไฟล์ OVPN EHI ทั้งหมด </span></a></li>
                    </false>
                </check>
                <li class="header">เพิ่มเติม</li>
                <li class="treeview">
                    <a href="#">
                    <i class="fa fa-facebook"></i>
                    <span>FACEBOOK</span>
                    <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                    </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="https://www.facebook.com/MooChomtong"><i class="fa fa-facebook-official"></i> <span> FACEBOOK GROUP </span></a></li>
                        <li><a href="https://m.me/chaivpn"><i class="fa fa-facebook-official"></i> <span> FACEBOOK ME </span></a></li>
                    </ul>
                				<li><a href="/profile"><i class="fa fa-shield"></i> <span> PROFILE EDIT </span></a></li>
                				<li><a href="/logout" ><i class="fa fa-sign-out" ></i><span> ออกจากระบบ </span></a></li>
            </ul>
        </section>
    </aside>
    <include href="{{ @subcontent }}"/>
    <footer class="main-footer text-center">
        <div class="pull-right hidden-xs">
        </div>
        <strong> <a href="/"> MOO VPN</a></strong>
    </footer>
    <div class="control-sidebar-bg"></div>
</div>