<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
 <div class="content-wrapper">
    <section class="content-header">
      <h1>
        PROFILE DETAIL
      </h1>
      <ol class="breadcrumb">
        <li><a href="/dashboard"><i class="fa fa-fort-awesome"></i> DASHBOARD </a></li>
        <li class="active"> PROFILE </li>
      </ol>
    </section>
    
    <section class="content">
  	 <div class="row">
   	  <div class="col-sm-6 col-md-4 col-lg-3">     
	  	  <check if="{{ @message }}">     
				<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-warning"></i>SUCCESS!</h4>
                {{ @message['data'] }}
              </div>
            </check>
       </div>

       <div class="col-md-12">
          <div class="box box-widget widget-user">
             <div class="widget-user-header bg-black" style="background: url('/bootstrap/asset/img/check-hea.png') center center;">
              <h3 class="widget-user-username text-center">จำนวนเงินคงเหลือ {{ @me->banking }} บาท</h3>
              <a href="/dashboard" class="btn btn-default pull-right"><i class="fa fa-arrow-left"></i> BACK </a>
			  <a href="/wallet" class="btn btn-primary pull-left"><i class="fa fa-buysellads"></i> TOPUP </a>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="/bootstrap/asset/img/user3-128x128.png" alt="User Avatar">
            </div>
 
		  <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">รายละเอียด</span></span>
      </div>
      <ul class="nav nav-stacked">
                <li><a href="#"><B> USERNAME </B><span class="pull-right"><span style="font-size: 16px;" class="badge bg-aqua"> {{ @me->username }} </span></span></a></li>
                <li><a href="#"><B> E-MAIL </B><span style="font-size: 16px;" class="pull-right badge bg-purple">{{ @me->email }}</span></a></li>
          </ul> 
        </div>

      	<div class="box-footer">
           <center><span class="description-text"><span style="font-size: 16px;"  class="badge bg-maroon"> เปลี่ยนรหัสผ่าน </span></span></center>
         <br>
			<form role="form" action="{{ @URI }}" method="POST">
              <div class="box-body">
                 <div class="form-group">
                    <label>รหัสผ่านเก่า</label>
                        <input class="form-control" placeholder="รหัสผ่านเก่า" name="oldpass" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>รหัสผ่านใหม่</label>
                            <input class="form-control" placeholder="รหัสผ่านใหม่" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>รหัสผ่านใหม่ อีกครั้ง</label>
                            <input class="form-control" placeholder="ยืนยันรหัสผ่านอีกครั้ง" name="password_confirmation" type="password" required>
                        </div>
                     </div>

					<button type="submit" class="btn btn-success pull-left"><i class="fa fa-ge"></i> ยืนยัน </button>
							
	<a href="/dashboard" class="btn btn-warning pull-right"><i class="fa fa-fort-awesome"></i> ย้อนกลับ </a>
				</form>     
						</div>
					</div>        
		
			</div> 
		</div> 
    </section>

	
</div>