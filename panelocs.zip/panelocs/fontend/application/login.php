<head>
<meta content="authenticity_token" name="csrf-param" />
<meta content="R2gDnRjk6uVNhK1JYA6Kw6zNt7b1woMVmPGoa9f6Ay4=" name="csrf-token" />
<link href="/bootstrap/assets/favicon-577672b73875cfc990d07ad2b4365929.png" rel="icon" style="image/png"></link>
<link href="/bootstrap/assets/v5/sub-5dd9fd7c2dff8081a020e5d0a27b4995.css" media="screen" rel="stylesheet" />
<script src="/bootstrap/assets/v5-sub/sub-bb03a8403b3126e55efdd0ab040df9d3.js"></script>
<!--[if lte IE 9 ]>
<link href="/bootstrap/assets/v5/ie-7318f58c8b118c2918bc7c57dd36e68f.css" media="screen" rel="stylesheet" />
<script src="/bootstrap/assets/vendor/jquery.placeholder-68f30622d8e83430448325c2cd98873c.js"></script>

<script>
  $(document).on('ready', function() {
    $('input, textarea').placeholder();
  });
</script>
<![endif]--> 
</head>
<center>
<img src ="https://www.moovpn.net/bootstrap/img/moo.png" width="170" height="170" >

<h2 class='page-heading'>
MOOVPN
</h2>
<div class='container container--narrow u-background-dark'>
	
	<check if="{{ @message }}">
       <div class="alert alert-{{ @message['type'] }}">{{ @message['data'] }}
        </div>
    </check>

		<form accept-charset="UTF-8" action="/login" method="post">
			<div style="margin:0;padding:0;display:inline">
				<input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="R2gDnRjk6uVNhK1JYA6Kw6zNt7b1woMVmPGoa9f6Ay4=" /></div>
				<input id="return_to" name="return_to" type="hidden" value="/" />
				<div class='form__group'>
					<input class="form-control" type="username" name="username" placeholder="Enter your username" spellcheck="false" />
				</div>
				<div class='form__group'>
					<input class="form-control" type="password" name="password" placeholder="Enter your password" />
				</div>
				<div class='form__group'>
					<input class="button button--block" name="commit" type="submit" value="เข้าสู่ระบบ MOOVPN" />
				</div>
				
				<h2 class='form__reset'><a href="/signup"><b>สมัครสมาชิก</b></a>
</h2>
</form>

</div>
