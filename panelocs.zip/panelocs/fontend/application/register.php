<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="MOOVPN เน็ตเร็ว แรง ดี ที่พี่เทพ รอยคอ เห้ย!! คอยรอ เห้ย!! รอคอย เห้ย!! ถูกแล้ว...">
    <meta name="author" content="MOOVPN">
    <title>MOOVPN</title>
    <link rel="stylesheet" href="/bootstrap/asset/css/bootstrap.min.css" type="text/css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="/bootstrap/asset/font-awesome/css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="/bootstrap/asset/css/animate.min.css" type="text/css">
    <link rel="stylesheet" href="/bootstrap/asset/css/creative.css" type="text/css">

    <!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
	<![endif]-->
<style>
body {
    background:url('/bootstrap/black-hole.gif') repeat-y 100% 100% fixed;
    background-position: center;
    height:100%;
    width:100%;
}
</style>
<link rel="shortcut icon" href="/bootstrap/favicon/favicon.ico" type="image/x-icon" />
<link rel="apple-touch-icon" href="/bootstrap/favicon/apple-icon.png" />
<link rel="apple-touch-icon" sizes="57x57" href="/bootstrap/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/bootstrap/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/bootstrap/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/bootstrap/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/bootstrap/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/bootstrap/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/bootstrap/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/bootstrap/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/bootstrap/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/bootstrap/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/bootstrap/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/bootstrap/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/bootstrap/favicon/favicon-16x16.png">
<link rel="manifest" href="/bootstrap/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/bootstrap/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
</head>

<body id="page-top">
    <section id="services">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-6 col-xs-12 text-center">                   
                    <br /><p>
					<h1 style='color:red'><b> MOO-VPN </b></h1>
					<p>
                </div>
            </div>
        </div>
		<br /><br />
					
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-6 col-xs-12">
                    <div class="col-md-12">
                        <check if="{{ @message }}">
                            <div class="alert alert-{{ @message['type'] }}">{{ @message['data'] }}
                            </div>
                        </check>
                        <form action="/signup" method="post">
                            <div class="col-lg-12">
                                <div class="panel-body">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="username" style='color:white'>  E-MAIL
                                            </label>
                                            <input type="text" name="email" placeholder="EMAIL" class="form-control" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="username" style='color:white'>  USER NAME
                                            </label>
                                            <input type="text" name="username" placeholder="Username" class="form-control" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="password" style='color:white'>  PASSWORD
                                            </label>
                                            <input type="password" name="password" placeholder="Password" class="form-control" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="password" style='color:white'>  RE-PASSWORD
                                            </label>
                                            <input type="password" name="password_confirmation" placeholder="Password" class="form-control" required>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" name="submit" class="btn btn-success pull-left">
                                            <i class="fa fa-lock">
											</i> SIGN-UP
                                            </button>
                                            <a href="/" class="btn btn-danger pull-right">
                                                <i class="fa fa-unlock">
												</i> LOG-IN
                                            </a>
                                        </div>
                                    </div>
                                </div>
                        </form>
                        </div>
                        <div class="col-md-6 col-md-6 col-xs-12 text-center">
                            <a class="page-scroll" href="https://www.facebook.com/MooChomtong">
                                <span class="badge bg-blue">FACEBOOK GROUP</span>
                            </a>

                        </div>
                    </div>
                </div>
            </div>
    </section>
    <script src="/bootstrap/asset/js-signup/jquery.js"></script>
    <script src="/bootstrap/asset/js-signup/bootstrap.min.js"></script>
    <script src="/bootstrap/asset/js-signup/jquery.easing.min.js"></script>
    <script src="/bootstrap/asset/js-signup/jquery.fittext.js"></script>
    <script src="/bootstrap/asset/js-signup/wow.min.js"></script>
    <script src="/bootstrap/asset/js-signup/creative.js"></script>
</body>

</html>                        
                        
                        
                        
                        