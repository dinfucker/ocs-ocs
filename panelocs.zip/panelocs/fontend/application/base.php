<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->

<head>
    <title>MOO-VPN</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta property="og:title" content="MOO-VPN เร็วแรง" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://www.moovpn.net/" />
    <meta property="og:image" content="https://www.moovpn.net/bootstrap/img/moo2.jpg" />
    <meta property="og:description" content="moo-vpn บริการเช่าอินเตอร์เน็ต ระบบ VPN " />
    <meta property="og:site_name" content="MOO-VPN" />
	  <meta property="og:image:alt" content="https://www.blackhole-vpn.tk/bootstrap/img/blackhole-10.jpg" />
    <link rel="apple-touch-icon" sizes="120x120" href="/bootstrap/favicon/apple-icon.png">
    <link rel="manifest" href="/bootstrap/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/bootstrap/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <link rel="shortcut icon" href="/bootstrap/favicon/favicon.ico" type="image/x-icon" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-beta-3/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.0/css/mdb.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/bootstrap/plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="/bootstrap/asset/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="/bootstrap/asset/dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="/bootstrap/asset/dist/css/skins/_all-skins.min.css">
    <link href="/bootstrap/asset/css/bootstrap-dialog.min.css" rel="stylesheet">
    <link href="/bootstrap/asset/css/animate.min.css" rel="stylesheet" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-111702601-3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-111702601-3');
</script>
 <style>
    .example-modal .modal {
      position: relative;
      top: auto;
      bottom: auto;
      right: auto;
      left: auto;
      display: block;
      z-index: 1;
    }

    .example-modal .modal {
      background: transparent !important;
    }
  </style>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="/bootstrap/asset/font-awesome/css/font-awesome.min.css" type="text/css">    
    <link rel="stylesheet" href="/bootstrap/asset/css/animate.min.css" type="text/css">
    <link rel="stylesheet" href="/bootstrap/asset/css/creativ.css" type="text/css">
<style>
.u-background-dark {
  background: #2A343C;
}
</style> 
</head>
<body oncopy="return false" oncut="return false" onpaste="return false" class="hold-transition skin-blue fixed sidebar-mini u-background-dark">
    <include href="{{ @content}} "/>

<script src="/bootstrap/plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/metisMenu/2.0.0/metisMenu.min.js"></script>
<link rel="stylesheet" href="/bootstrap/plugins/daterangepicker/daterangepicker.css">
<link rel="stylesheet" href="/bootstrap/plugins/datepicker/datepicker3.css">
<script src="/bootstrap/asset/js/bootstrap.min.js"></script>
<script src="/bootstrap/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="/bootstrap/plugins/fastclick/fastclick.js"></script>
<script src="/bootstrap/asset/dist/js/app.min.js"></script>
<script src="/bootstrap/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="/bootstrap/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script>
var _0x3800=['#lowclass'];(function(_0x5a7529,_0xfbb0de){var _0x27c0c2=function(_0x52cc96){while(--_0x52cc96){_0x5a7529['push'](_0x5a7529['shift']());}};_0x27c0c2(++_0xfbb0de);}(_0x3800,0x106));var _0x20e6=function(_0x236e81,_0x197503){_0x236e81=_0x236e81-0x0;var _0x39a462=_0x3800[_0x236e81];return _0x39a462;};$(function(){$(_0x20e6('0x0'))['DataTable']({'aLengthMenu':[[0x1,-0x1]],'paging':!![],'lengthChange':![],'searching':!![],'ordering':![],'info':!![],'autoWidth':![]});});
</script>
<script>
  var _0x575f=['DataTable','#blackhole'];(function(_0x2d2bfb,_0x4c3732){var _0x4c61f8=function(_0x2c03e6){while(--_0x2c03e6){_0x2d2bfb['push'](_0x2d2bfb['shift']());}};_0x4c61f8(++_0x4c3732);}(_0x575f,0x7d));var _0x9d5a=function(_0x211eb7,_0x1ac218){_0x211eb7=_0x211eb7-0x0;var _0x46a156=_0x575f[_0x211eb7];return _0x46a156;};$(function(){$(_0x9d5a('0x0'))[_0x9d5a('0x1')]({'paging':!![],'lengthChange':!![],'searching':!![],'ordering':!![],'info':!![],'autoWidth':![]});});
</script>
  <script src="/bootstrap/plugins/datepicker/bootstrap-datepicker.js"></script>
    <script src="/bootstrap/asset/js/bootstrap-dialog.min.js"></script>
    <script>
        var _0x473b=['ยกเลิก','btn-danger','href','.input-group.date','datepicker','.hapus','click','preventDefault','confirm','Confirm','\x20Are\x20you\x20sure?','TYPE_DANGER'];(function(_0x5eba16,_0x462c02){var _0x5a338c=function(_0x33b02a){while(--_0x33b02a){_0x5eba16['push'](_0x5eba16['shift']());}};_0x5a338c(++_0x462c02);}(_0x473b,0x1bf));var _0xf53d=function(_0xe99bc8,_0x3bb7d6){_0xe99bc8=_0xe99bc8-0x0;var _0x5c1e32=_0x473b[_0xe99bc8];return _0x5c1e32;};$(_0xf53d('0x0'))[_0xf53d('0x1')]({'format':'yyyy/mm/dd','weekStart':0x1,'clearBtn':!![],'language':'th','autoclose':!![],'todayHighlight':!![]});$(_0xf53d('0x2'))[_0xf53d('0x3')](function(_0x44d2f4){_0x44d2f4[_0xf53d('0x4')]();BootstrapDialog[_0xf53d('0x5')]({'title':_0xf53d('0x6'),'message':_0xf53d('0x7'),'type':BootstrapDialog[_0xf53d('0x8')],'closable':!![],'btnCancelLabel':_0xf53d('0x9'),'btnOKLabel':'ลบ','btnOKClass':_0xf53d('0xa'),'callback':function(_0x4067ce){if(_0x4067ce){location[_0xf53d('0xb')]=$(_0xf53d('0x2'))['attr'](_0xf53d('0xb'));}}});});function print_report(){window['print']();return![];}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.13.0/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.0/js/mdb.min.js"></script>
</body>
</html>