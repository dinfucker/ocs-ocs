<?php defined('BASEPATH') OR exit('No direct script access allowed');
[globals]
DEBUG=0
AUTOLOAD="system/controller/;system/model/"
UI="fontend/application/"
APP_KEY="e64f86648be19a8e050746046e691991636253fd4f7a66659b47f0532793d1bf"
DB_SET="mysql:host=localhost;port=10000;dbname=BLACKHOLE"
DB_USER="root"
DB_PASS="!@#122345!@#"
?>